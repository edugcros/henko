// 📁 app.js
import express from 'express'
import cookieParser from 'cookie-parser'
import helmet from 'helmet'
import morgan from 'morgan'
import cors from 'cors'
import dotenv from 'dotenv'
import { csrfProtection, logCsrf, attachCsrfToken, detectNgrok } from './src/middlewares/csrfMiddleware.js'
import { notFound, errorHandler } from './src/middlewares/errorHandler.js'
import apiRoutes from './src/routes/index.js'
import mongoSanitize from 'express-mongo-sanitize'
import { fileURLToPath } from 'url'
import path from 'path'

dotenv.config({
  path: process.env.NODE_ENV === 'production'
    ? '.env.production'
    : '.env.development',
})

const app = express()
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// ------------------------------------------------------------
// 🔒 CORS — UNIVERSAL (Localhost, LAN, ngrok, Móviles)
// ------------------------------------------------------------

const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001',
  'http://127.0.0.1:3001',
  'http://10.0.7.166:3001',
  'https://vivan-humblest-mercy.ngrok-free.dev',
]

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true) // Postman, curl

    const isNgrok = origin.includes('ngrok-free') || origin.includes('ngrok.app')

    if (allowedOrigins.includes(origin) || isNgrok) return callback(null, true)

    console.error('❌ CORS BLOCKED:', origin)
    return callback(new Error('CORS not allowed'))
  },
  credentials: true,
  allowedHeaders: [
    'Content-Type',
    'Authorization',
    'X-CSRF-Token',
    'x-csrf-token',
  ],
  exposedHeaders: ['x-csrf-token'],
}

app.use(cors(corsOptions))
app.options('*', cors(corsOptions))

// ------------------------------------------------------------
// 🛡 Middlewares base
// ------------------------------------------------------------
app.use(helmet())
app.use(morgan('dev'))
app.use(cookieParser())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'))
app.use(mongoSanitize())
app.use('/images', express.static(path.join(__dirname, 'public/images')))

// ------------------------------------------------------------
// 🟢 CSRF — CONFIG PARA LOCALHOST + NGROK + PRODUCCIÓN
// ------------------------------------------------------------

// Token por request y logging
app.use(detectNgrok)       // detecta si es ngrok
app.use(csrfProtection)    // protección CSRF base
app.use(attachCsrfToken)   // genera cookie X-CSRF-Token para frontend
app.use(logCsrf)  

// Manejo explícito de errores CSRF
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({
      success: false,
      message: 'CSRF inválido o ausente',
    })
  }
  next(err)
})

// ------------------------------------------------------------
// 🔗 API routes
// ------------------------------------------------------------
app.use('/api', apiRoutes)

// 404 + handler
app.use(notFound)
app.use(errorHandler)

export default app
