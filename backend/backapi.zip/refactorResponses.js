// refactorResponses.js
import fs from 'fs'
import path from 'path'

const controllerDir = './src/controller'

const sendResponseRegex = /res\.status\((\d{3})\)\.json\(\s*({[^}]+})\s*\)/g

const convertToSendResponse = (match, status, body) => {
  try {
    const json = eval(`(${body})`)
    const message = json.message ? `\`${json.message}\`` : '"OK"'
    const data = json.data ? 'data' : 'null'
    const isSuccess = status < 400 ? 'true' : 'false'
    return `sendResponse(res, ${status}, ${isSuccess}, ${message}, ${data})`
  } catch (err) {
    console.warn('⚠️ No se pudo parsear:', match, err)
    return match
  }
}

fs.readdirSync(controllerDir).forEach(file => {
  if (file.endsWith('.js')) {
    const filePath = path.join(controllerDir, file)
    let content = fs.readFileSync(filePath, 'utf-8')
    const newContent = content.replace(sendResponseRegex, convertToSendResponse)
    fs.writeFileSync(filePath, newContent, 'utf-8')
    console.log(`✅ Reemplazos aplicados en: ${file}`)
  }
})
