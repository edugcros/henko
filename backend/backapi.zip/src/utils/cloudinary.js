import { v2 as cloudinary } from 'cloudinary'
import dotenv from 'dotenv'
import logger from '../../config/logger.js'

dotenv.config()

// ===============================
//  VALIDACIÓN ESTRICTA DE ENV
// ===============================
const REQUIRED_ENV = [
  'CLOUDINARY_CLOUD_NAME',
  'CLOUDINARY_API_KEY',
  'CLOUDINARY_API_SECRET',
]

for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`❌ Variable de entorno faltante: ${key}`)
    throw new Error(`FALTA VARIABLE DE ENTORNO: ${key}`)
  }
}

// ===============================
//  CONFIGURACIÓN SEGURA
// ===============================
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
})

// ===============================
//  HELPERS
// ===============================
const uploadStream = (folder, buffer) =>
  new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: 'image',
        overwrite: false,
        // Anti-vulnerabilidad: sanitiza parámetros internos
        invalidate: true,
      },
      (err, result) => {
        if (err) return reject(err)
        resolve(result)
      },
    )
    stream.end(buffer)
  })

// ===============================
//  UPLOAD PRODUCT IMAGE
// ===============================
export const cloudinaryUploadImg = async (buffer, productId) => {
  const folder = `products/${productId}`

  try {
    const result = await uploadStream(folder, buffer)

    logger.info(`📤 Imagen subida a Cloudinary: ${result.secure_url}`)

    return {
      url: result.secure_url,
      asset_id: result.asset_id,
      public_id: result.public_id,
    }
  } catch (error) {
    logger.error('❌ Error Cloudinary (product upload):', {
      message: error.message,
      name: error.name,
      http_code: error.http_code,
      code: error.code,
    })

    throw new Error('Error interno al subir imagen del producto')
  }
}

// ===============================
//  UPLOAD BLOG IMAGE
// ===============================
export const cloudinaryUploadBlogImg = async (buffer, blogId) => {
  const folder = `blogs/${blogId}`

  try {
    const result = await uploadStream(folder, buffer)

    logger.info(`📤 Imagen de blog subida: ${result.secure_url}`)

    return {
      url: result.secure_url,
      asset_id: result.asset_id,
      public_id: result.public_id,
    }
  } catch (error) {
    logger.error('❌ Error Cloudinary (blog upload):', {
      message: error.message,
      name: error.name,
      http_code: error.http_code,
      code: error.code,
    })

    throw new Error('Error interno al subir imagen del blog')
  }
}
