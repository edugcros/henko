import slugify from 'slugify'
import Product from '../models/productModel.js'

export async function generateUniqueSlug({ title, tenantId }) {
  const baseSlug = slugify(title, {
    lower: true,
    strict: true,
    trim: true,
  }).slice(0, 80)

  let slug = baseSlug
  let counter = 1

  while (await Product.exists({ tenantId, slug })) {
    counter++
    slug = `${baseSlug}-${counter}`
  }

  return slug
}
