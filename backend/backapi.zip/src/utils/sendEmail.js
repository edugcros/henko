import transporter from '../../config/emailConfig.js'
import dotenv from 'dotenv'
import logger from '../../config/logger.js'
dotenv.config()

export const sendEmail = async ({ to, subject, text, html, attachments = [], replyTo }) => {
  // ✅ Validación mejorada: Asegura que el contenido (texto o HTML) no esté vacío.
  if (!to || !subject || (!text && !html) || (text && text.trim() === '' && html && html.trim() === '')) {
    throw new Error('Faltan parámetros o el contenido del email está vacío')
  }

  const mailOptions = {
    from: `"E-commerce" <${process.env.EMAIL_USER}>`,
    to,
    subject: subject.trim(),
    text,
    html,
    attachments,
    ...(replyTo ? { replyTo } : {}),
  }

  try {
    const info = await transporter.sendMail(mailOptions)
    logger.info('Correo enviado', { messageId: info.messageId, to })
    return { success: true, message: 'Correo enviado correctamente', info }
  } catch (error) {
    logger.error('Error al enviar correo', { error: error.message, to })
    // Relanza un error con un mensaje más claro para el controlador
    throw new Error('No se pudo enviar el correo')
  }
}
