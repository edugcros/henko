import express from 'express'
import {
  getMyStores,
  createStore,
  getStoreDesign,
  saveStoreDesign,
  deleteStoreDesign,
} from '../controller/storeUnifiedController.js'
import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'

const router = express.Router()

// -------- TIENDAS ---------
router.get('/store/my-stores', authMiddleware, getMyStores)       // GET todas las tiendas del usuario autenticado
router.post('/store', authMiddleware, createStore)                // POST crear nueva tienda

// -------- DISEÑO DE TIENDA --------
router.get('/store-design/:storeId', getStoreDesign)              // GET diseño de tienda (público)
router.post('/store-design/:storeId', authMiddleware, isAdmin, saveStoreDesign) // POST guardar/actualizar diseño (solo admin de tienda)
router.put('/store-design/:storeId', authMiddleware, isAdmin, saveStoreDesign)  // PUT igual que POST, opcional
router.delete('/store-design/:storeId', authMiddleware, isAdmin, deleteStoreDesign) // DELETE resetear diseño (solo admin)

export default router
