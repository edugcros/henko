// 📁 routes/storeDesignRoute.js
import express from 'express'
import { 
  getStoreDesign, 
  saveStoreDesign, 
  deleteStoreDesign } from '../controller/storeUnifiedController.js'
import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'

const router = express.Router()

// GET: Obtener diseño actual de una tienda
router.get('/:storeId', getStoreDesign) // Público, cualquier visitante puede leer

// POST/PUT: Guardar o actualizar diseño (solo admin de tienda)
router.post('/:storeId', authMiddleware, isAdmin, saveStoreDesign)
router.put('/:storeId', authMiddleware, isAdmin, saveStoreDesign)

// Opcional: Resetear diseño (solo admin)
router.delete('/:storeId', authMiddleware, isAdmin, deleteStoreDesign)

export default router
