import express from 'express'
import {
  createCoupon,
  getAllCoupons,
  getCouponById,
  updateCoupon,
  deleteCoupon,
  validateCoupon,
} from '../controller/couponCtrl.js'

import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'
import { csrfProtection } from '../middlewares/csrfMiddleware.js'

const router = express.Router()

// 🔐 Rutas protegidas para administración
router.post('/', authMiddleware, isAdmin, createCoupon)
router.put('/:id', authMiddleware, isAdmin, updateCoupon)
router.delete('/:id', authMiddleware, isAdmin, deleteCoupon)

// 🟢 Rutas públicas o para frontend verificado
router.get('/', csrfProtection, getAllCoupons)
router.get('/:id', csrfProtection, getCouponById)

// Validar cupón (para frontend)
router.post('/validate', csrfProtection, validateCoupon)


export default router
