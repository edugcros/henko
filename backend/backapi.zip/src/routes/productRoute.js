// 📦 routes/productRoute.js
import express from 'express'
import {
  createProduct,
  getaProduct,
  getAllProduct,
  updateProduct,
  deleteProduct,
  rating,
  rateLimiter,
  deleteProductImage,
  uploadProductImage,
} from '../controller/productCtrl.js'
import { isAdmin, authMiddleware } from '../middlewares/authMiddleware.js'
import { uploadPhoto, productImgResize } from '../middlewares/uploadImage.js'
import { validateMongoDbIdMiddleware } from '../utils/validation.js'

const router = express.Router()

// Admin: Crear producto (sin imágenes)
router.post(
  '/',
  authMiddleware,
  isAdmin,
  createProduct,
)

// Admin: Actualizar producto
router.put(
  '/:productId',
  authMiddleware,
  isAdmin,
  validateMongoDbIdMiddleware,
  updateProduct,
)

// Admin: Eliminar producto
router.delete('/:productId', authMiddleware, isAdmin, validateMongoDbIdMiddleware, deleteProduct)

// Público y autenticado
router.get('/', rateLimiter, getAllProduct)
router.get('/:id', getaProduct)
router.put('/rating', authMiddleware, rating)

router.post(
  '/:productId/upload-image', // ⬅️ Ruta dedicada para subir la imagen
  authMiddleware, // ⬅️ Middleware de seguridad
  isAdmin,
  uploadPhoto.single('imageFile'),
  productImgResize,
  uploadProductImage,
)

// DELETE /api/product/:productId/:public_id
router.delete(
  '/:productId',
  authMiddleware,
  isAdmin,
  deleteProductImage,
)

export default router