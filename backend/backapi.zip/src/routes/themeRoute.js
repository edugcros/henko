// themeRoute.js
import express from 'express'
import rateLimit from 'express-rate-limit'
import { csrfProtection } from '../middlewares/csrfMiddleware.js'
import { authMiddleware } from '../middlewares/authMiddleware.js'
import {
  getPublishedTheme,
  getThemes,
  createThemeDraft,
  updateTheme,
  publishTheme,
  getThemeById,
} from '../controller/themeController.js'

const router = express.Router()
const themeLimiter = rateLimit({ windowMs: 5000, max: 25 })

// PUBLIC
router.get('/published', themeLimiter, csrfProtection, getPublishedTheme)

// PRIVATE
router.get('/', themeLimiter, csrfProtection, authMiddleware, getThemes)
router.post('/', themeLimiter, csrfProtection, authMiddleware, createThemeDraft)
router.patch('/:id', themeLimiter, csrfProtection, authMiddleware, updateTheme)
router.post('/:id/publish', themeLimiter, csrfProtection, authMiddleware, publishTheme)
router.get('/:id', themeLimiter, csrfProtection, authMiddleware, getThemeById)


export default router
