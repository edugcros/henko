import express from 'express'
import {
  createUser,
  loginUser,
  loginAdmin,
  getCurrentUser,
  handleRefreshToken,
  logout,
  forgotPassword,
  forgotPasswordLimiter,
  resetPassword,
  updatePassword,
  getAllUsers,
  getUserById,
  deleteUser,
  updateUser,
  blockUser,
  unblockUser,
  getWishlist,
  toggleWishlist, // ✅ Importa el nuevo controlador
  saveAddress,
  validateAddress ,
  userCart,
  getUserCart,
  emptyCart,
  applyCoupon,
  removeFromCart,
  getCsrfToken,
} from '../controller/userCtrl.js'

import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'
import { csrfProtection } from '../middlewares/csrfMiddleware.js'


const router = express.Router()

// 🔓 Público
router.get('/csrf-token', getCsrfToken)
router.post('/register', csrfProtection, createUser)
router.post('/login', csrfProtection, loginUser)
router.post('/admin-login', csrfProtection, loginAdmin)
router.get('/refresh', csrfProtection, handleRefreshToken)
router.post('/logout', csrfProtection, logout)
router.post('/forgot-password',csrfProtection, forgotPasswordLimiter, forgotPassword)
router.put('/reset-password/:token', csrfProtection, resetPassword)

// 👤 Usuario autenticado
router.get('/me', authMiddleware, csrfProtection, getCurrentUser)
router.put('/password', authMiddleware, csrfProtection, updatePassword)
router.put('/edit-user', authMiddleware, csrfProtection, updateUser)
router.get('/wishlist', authMiddleware, csrfProtection, getWishlist)
router.put('/wishlist/:productId', authMiddleware, csrfProtection, toggleWishlist) // ✅ Ruta corregida
router.put('/save-address', authMiddleware, csrfProtection,validateAddress , saveAddress)

// 🛒 Carrito
router.post('/cart', authMiddleware, csrfProtection, userCart)
router.get('/user-cart', authMiddleware, csrfProtection, getUserCart)
router.delete('/cart/empty', authMiddleware, csrfProtection, emptyCart)
router.put('/cart/apply-coupon', authMiddleware, csrfProtection, applyCoupon)
router.delete('/cart/product/:productId', authMiddleware, csrfProtection, removeFromCart)

// 🔐 Admin
router.get('/all-users', authMiddleware, csrfProtection,isAdmin, getAllUsers)
router.get('/:id', authMiddleware,csrfProtection, isAdmin, getUserById)
router.delete('/:id', authMiddleware,csrfProtection, isAdmin, deleteUser)
router.put('/block-user/:id', authMiddleware,csrfProtection, isAdmin, blockUser)
router.put('/unblock-user/:id', authMiddleware,csrfProtection, isAdmin, unblockUser)

export default router