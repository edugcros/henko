// 📁 routes/orderRoute.js

import express from 'express'
import {
  createOrder,
  getOrders,
  getAllOrders,
  updateOrderStatus,
} from '../controller/orderCtrl.js'

import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'
import { csrfProtection } from '../middlewares/csrfMiddleware.js'

const router = express.Router()

// 🛒 Órdenes del usuario autenticado
router.post('/create', authMiddleware, csrfProtection, createOrder)
router.get('/getAll', authMiddleware, csrfProtection, getAllOrders)

// 🛒 Administración de órdenes (solo admin)
router.get('/order', authMiddleware, csrfProtection, isAdmin, getOrders)
router.put('/:id/status', authMiddleware, csrfProtection, isAdmin, updateOrderStatus)

export default router
