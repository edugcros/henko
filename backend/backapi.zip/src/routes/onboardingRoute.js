import express from 'express'
import {
  onboardingAIHandler,
  saveOnboardingResult,
  getMyOnboardingResults,
  deleteOnboardingResult,
  updateOnboardingResult,
} from '../controller/onboardingCtrl.js'

import { authMiddleware } from '../middlewares/authMiddleware.js'
import { csrfProtection } from '../middlewares/csrfMiddleware.js'

const router = express.Router()

router.post('/suggest', csrfProtection, onboardingAIHandler)
router.post('/save', authMiddleware, csrfProtection, saveOnboardingResult)
router.get('/my', authMiddleware, getMyOnboardingResults)
router.delete('/:id', authMiddleware, csrfProtection, deleteOnboardingResult)
router.put('/:id', authMiddleware, csrfProtection, updateOnboardingResult)

export default router
