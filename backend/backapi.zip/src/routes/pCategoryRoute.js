import express from 'express'
import {
  createProductCategory,
  updateProductCategory,
  deleteProductCategory,
  getProductCategoryById,
  getAllProductCategories,
} from '../controller/pCategoryCtrl.js'
import { authMiddleware, isAdmin } from '../middlewares/authMiddleware.js'

const router = express.Router()

router.post('/', authMiddleware, isAdmin, createProductCategory)
router.put('/:id', authMiddleware, isAdmin, updateProductCategory)
router.delete('/:id', authMiddleware, isAdmin, deleteProductCategory)
router.get('/:id', getProductCategoryById)
router.get('/', getAllProductCategories)

export default router
