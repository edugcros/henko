import express from 'express'

import userRoute from './userRoute.js'
import productRouter from './productRoute.js'
import pCategoryRoute from './pCategoryRoute.js'
import brandRouter from './brandRoute.js'
import colorRouter from './colorRoute.js'
import enqRouter from './enqRoute.js'
import emailRoutes from './emailRoute.js'
import couponRouter from './couponRoute.js'
import onboardingRoute from './onboardingRoute.js'
import orderRoute from './orderRoute.js'
import storeRoute from './storeUnifiedRoutes.js'
import uploadRoutes from './uploadRoute.js'
import themeRoute from './themeRoute.js'
const router = express.Router()

// 🔐 Usuarios y autenticación
router.use('/user', userRoute)
router.use('/store-design', storeRoute)
router.use('/', storeRoute)

// 🛍️ Productos, categorías, marcas y colores
router.use('/product', productRouter)
router.use('/imgup', uploadRoutes)
router.use('/category', pCategoryRoute)
router.use('/brand', brandRouter)
router.use('/color', colorRouter)
router.use('/coupon', couponRouter)
router.use('/theme', themeRoute)


// 📬 Contacto / Consultas
router.use('/enquiry', enqRouter)

// 📧 Email (tokens, contacto)
router.use('/email', emailRoutes)

// 🤖 Onboarding IA
router.use('/onboarding-ai', onboardingRoute)

router.use('/order', orderRoute)

export default router
