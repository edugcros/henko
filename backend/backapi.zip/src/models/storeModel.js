import mongoose from 'mongoose'

const storeSchema = new mongoose.Schema(
  {
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Users',
      required: true,
      unique: true, // Una tienda por usuario
    },
    name: { type: String, required: true, trim: true },
    description: { type: String, default: '', trim: true },
    logo: { type: String, default: null },
    initializedFromAI: { type: Boolean, default: false },
    status: {
      type: String,
      enum: ['draft', 'active', 'disabled'],
      default: 'draft',
    },
    domain: { type: String, default: null },
    theme: {
      type: String,
      enum: ['default', 'modern', 'minimal', 'classic'],
      default: 'default',
    },
    settings: {
      colors: {
        primary: { type: String, default: '#000000' },
        secondary: { type: String, default: '#ffffff' },
      },
      currency: { type: String, default: 'ARS' },
    },
  },
  { timestamps: true },
)

export default mongoose.model('Store', storeSchema)
