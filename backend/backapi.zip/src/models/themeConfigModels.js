// src/models/themeConfig.js
import mongoose from 'mongoose'

const SectionSchema = new mongoose.Schema({
  type: { type: String, required: true },
  enabled: { type: Boolean, default: true },
  order: { type: Number, default: 0 },
  data: { type: mongoose.Schema.Types.Mixed, default: {} },
}, { _id: false })

const ThemeConfigSchema = new mongoose.Schema({
  tenantId: { type: String, required: true }, // obligatorio para multi-tenant
  name: { type: String, default: 'Nuevo tema' },
  version: { type: Number, default: 1 },
  status: { type: String, enum: ['draft', 'published'], default: 'draft' },

  metadata: {
    createdBy: { type: String, default: 'system' },
    createdAt: { type: Date, default: Date.now },
    updatedBy: { type: String, default: 'system' },
    updatedAt: { type: Date, default: Date.now },
  },

  colors: {
    primary: { type: String, default: '#1976d2' },
    secondary: { type: String, default: '#9c27b0' },
    background: { type: String, default: '#ffffff' },
    text: { type: String, default: '#222222' },
    headerBg: { type: String, default: '#1976d2' },
    footerBg: { type: String, default: '#f5f5f5' },
  },

  typography: {
    primaryFont: { type: String, default: 'Roboto, Arial' },
    headingSize: { type: String, default: '1.25rem' },
  },

  layout: {
    headerVariant: { type: String, default: 'minimal' },
    homeSections: { type: [SectionSchema], default: [] },
  },

  productCard: {
    variant: { type: String, default: 'simple' },
    showRating: { type: Boolean, default: true },
    quickView: { type: Boolean, default: true },
  },

}, { timestamps: true })

// Índice para published lookup rápido por tenant
ThemeConfigSchema.index({ tenantId: 1, status: 1 })

// Middleware: sincroniza metadata.updatedAt y updatedBy
ThemeConfigSchema.pre('save', function(next) {
  this.metadata.updatedAt = new Date()
  if (!this.metadata.updatedBy) this.metadata.updatedBy = 'system'
  next()
})

const ThemeConfig = mongoose.model('Theme', ThemeConfigSchema)
export default ThemeConfig
