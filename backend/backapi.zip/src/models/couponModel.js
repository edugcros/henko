import mongoose from 'mongoose'

const couponSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'El nombre del cupón es obligatorio'],
      unique: true,
      uppercase: true,
      trim: true,
      minlength: [3, 'El nombre del cupón debe tener al menos 3 caracteres'],
      maxlength: [20, 'El nombre del cupón no puede superar los 20 caracteres'],
    },
    expiry: {
      type: Date,
      required: [true, 'La fecha de expiración es obligatoria'],
      validate: {
        validator: function (v) {
          return v > Date.now()
        },
        message: 'La fecha de expiración debe ser en el futuro',
      },
    },
    discount: {
      type: Number,
      required: [true, 'El valor del descuento es obligatorio'],
      min: [0, 'El descuento no puede ser negativo'],
      max: [100, 'El descuento no puede superar el 100%'],
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    usageLimit: {
      type: Number,
      default: 1,
      min: [1, 'El límite de uso debe ser al menos 1'],
      validate: {
        validator: function (v) {
          return v >= this.usedCount
        },
        message: 'El límite de uso no puede ser menor que el número de usos actuales',
      },
    },
    usedCount: {
      type: Number,
      default: 0,
      min: [0, 'El número de usos no puede ser negativo'],
    },
  },
  { timestamps: true },
)

// Método para verificar si el cupón es válido y motivo si no lo es
couponSchema.methods.isValid = function () {
  if (!this.isActive) return { valid: false, reason: 'Cupón inactivo' }
  if (this.expiry <= Date.now()) return { valid: false, reason: 'Cupón expirado' }
  if (this.usedCount >= this.usageLimit) return { valid: false, reason: 'Límite de uso alcanzado' }
  return { valid: true }
}

couponSchema.index({ expiry: 1, isActive: 1 })

const Coupon = mongoose.model('Coupon', couponSchema)

export default Coupon
