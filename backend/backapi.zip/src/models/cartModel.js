// models/Cart.js
import mongoose from 'mongoose'

/* ================================
   Cart Item
================================ */
const cartItemSchema = new mongoose.Schema(
  {
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
      min: 1,
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    currency: {
      type: String,
      default: 'ARS',
      uppercase: true,
    },
    colorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Color',
      default: null,
    },
    size: {
      type: String,
      default: null,
      trim: true,
    },
    gender: {
      type: String,
      enum: ['Hombre', 'Mujer', 'Niño', null],
      default: null,
    },
    image: {
      type: String,
      default: null,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    subtotal: {
      type: Number,
      required: true,
      min: 0,
    },
  },
  { timestamps: false },
)

/* ================================
   Cart
================================ */
const cartSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    products: {
      type: [cartItemSchema],
      default: [],
    },
    appliedCoupon: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Coupon',
      default: null,
      index: true,
    },
    cartTotal: {
      type: Number,
      default: 0,
      min: 0,
    },
    totalAfterDiscount: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  { timestamps: true },
)

/* ================================
   Helpers
================================ */
cartSchema.methods.calculateTotals = function () {
  this.products.forEach(item => {
    item.subtotal = item.price * item.quantity
  })

  this.cartTotal = this.products.reduce(
    (acc, item) => acc + item.subtotal,
    0,
  )

  // si no hay cupón aplicado
  if (!this.appliedCoupon) {
    this.totalAfterDiscount = this.cartTotal
  }
}

/* ================================
   Add / Update Product
================================ */
cartSchema.methods.addOrUpdateProduct = async function ({
  product,
  quantity,
  colorId = null,
  size = null,
  gender = null,
}) {
  if (!product?._id) {
    throw new Error('Producto inválido')
  }

  const productId = product._id.toString()

  const existingItem = this.products.find(
    p =>
      p.productId.toString() === productId &&
      (!colorId || p.colorId?.toString() === colorId?.toString()) &&
      (!size || p.size === size) &&
      (!gender || p.gender === gender),
  )

  const newQuantity = existingItem
    ? existingItem.quantity + quantity
    : quantity

  if (
    typeof product.stock === 'number' &&
    newQuantity > product.stock
  ) {
    throw new Error(`Stock insuficiente. Disponible: ${product.stock}`)
  }

  let action = 'added'

  if (existingItem) {
    existingItem.quantity = newQuantity
    existingItem.price = product.price
    action = 'updated'
  } else {
    this.products.push({
      productId: product._id,
      quantity,
      price: product.price,
      currency: product.currency || 'ARS',
      colorId,
      size,
      gender,
      image: product.images?.[0]?.url || null,
      title: product.title,
      subtotal: product.price * quantity,
    })
  }

  this.calculateTotals()
  await this.save()

  return { action }
}

/* ================================
   Remove Product
================================ */
cartSchema.methods.removeProduct = async function (itemId) {
  this.products = this.products.filter(
    item => item._id.toString() !== itemId.toString(),
  )

  this.calculateTotals()
  await this.save()
}

/* ================================
   Indexes
================================ */
cartSchema.index({ userId: 1, updatedAt: -1 })

const Cart = mongoose.model('Cart', cartSchema)
export default Cart
