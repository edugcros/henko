// userModel.js
import mongoose from 'mongoose'
import bcrypt from 'bcrypt'
import crypto from 'crypto'
import sanitizeHtml from 'sanitize-html'
import dotenv from 'dotenv'

dotenv.config({
  path: process.env.NODE_ENV === 'production' ? '.env.production' : '.env.development',
})


// Helper: convierte formatos tipo "30m", "1h", "2d" → milisegundos
const parseExpireToMs = (value = '1h') => {
  const match = /^(\d+)([smhd])$/.exec(value)
  if (!match) return 3600000 // default: 1h
  const [, amount, unit] = match
  const num = parseInt(amount, 10)
  switch (unit) {
  case 's': return num * 1000
  case 'm': return num * 60 * 1000
  case 'h': return num * 60 * 60 * 1000
  case 'd': return num * 24 * 60 * 60 * 1000
  default: return 3600000
  }
}

const userSchema = new mongoose.Schema(
  {
    tenantId: {
      type: String,
      ref: 'Tenant', // si tienes un modelo Tenant
      required: true,
      index: true,
    },
    firstname: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
    },
    lastname: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
      validate: {
        validator: v =>
          /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(v),
        message: props => `${props.value} no es un email válido`,
      },
      
    },
    mobile: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
      validate: {
        validator: v =>
          /^\+?[1-9]\d{1,14}$/.test(v) && v.length >= 8 && v.length <= 15,
        message: props => `${props.value} no es un número de móvil válido`,
      }, 
    },
    password: {
      type: String,
      required: true,
    }, 
    role: {
      type: String,
      enum: {
        values: ['user', 'admin', 'moderator'],
        message: 'Rol no válido. Roles permitidos: user, admin, moderator',
      },
      default: 'user',
    },
    failedLoginAttempts: { type: Number, default: 0 },
    isBlocked: {
      type: Boolean,
      default: false,
      validate: {
        validator: v => typeof v === 'boolean',
        message: 'El valor de isBlocked debe ser booleano',
      },
    },
    address: {
      type: String,
      trim: true,
      maxlength: [200, 'La dirección no puede superar los 200 caracteres'],
    },
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
    refreshToken: { type: String, select: false },
    passwordChangedAt: { type: Date },
    passwordResetToken: { type: String, select: false },
    passwordResetExpires: Date,
  },
  { timestamps: true },
)


// ✅ Método correcto para ocultar campos sensibles
userSchema.methods.toSafeObject = function () {
  const safeUser = this.toObject() // Convierte el documento en objeto JS puro
  delete safeUser.password
  delete safeUser.refreshToken
  delete safeUser.__v
  delete safeUser.passwordChangedAt
  delete safeUser.passwordResetToken
  delete safeUser.passwordResetExpires
  return safeUser
}

// 🔹 Hash de contraseña antes de guardar
userSchema.pre('save', async function (next) {
  if (this.isModified('email')) {
    this.email = this.email.toLowerCase().trim()
  }

  if (this.isModified('mobile')) {
    this.mobile = this.mobile.trim()
  }

  if (this.isModified('address') && this.address.length <= 200) {
    this.address = sanitizeHtml(this.address, {
      allowedTags: [],
      allowedAttributes: {},
    })
  }

  if (!this.isModified('password')) return next()

  this.passwordChangedAt = Date.now() - 1000

  const salt = await bcrypt.genSalt(12)

  // ✅ Solo hashear si NO es un hash ya generado
  if (!/^\$2[aby]\$/.test(this.password)) {
    this.password = await bcrypt.hash(this.password, salt)
  }

  next()
})

userSchema.methods.changedPasswordAfter = function (JWTTimestamp = 0) {
  if (!this.passwordChangedAt) return false
  const changedTimestamp = Math.floor(this.passwordChangedAt.getTime() / 1000)
  return JWTTimestamp < changedTimestamp
}

userSchema.index({ email: 1 }, { unique: true, sparse: true })
userSchema.index({ mobile: 1 }, { unique: true, sparse: true })
userSchema.index({ isBlocked: 1, role: 1 })


// 🔹 Comparar contraseñas
userSchema.methods.isPasswordMatched = async function (enteredPassword) {
  if (!this.password) return false
  return await bcrypt.compare(enteredPassword, this.password)
}

// 🔹 Verificar si la contraseña cambió después del token JWT
// ✅ Versión refactorizada y segura
userSchema.methods.createPasswordResetToken = function () {
  // 🔸 Generar token plano
  const resetToken = crypto.randomBytes(32).toString('hex')

  // 🔸 Guardar hash en DB
  this.passwordResetToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex')

  // 🔸 Leer expiración configurable desde .env
  const expiresIn = parseExpireToMs(process.env.JWT_ACCESS_EXPIRES || '7d')
  this.passwordResetExpires = Date.now() + expiresIn

  return resetToken
}

//Verificar Si el Token de Recuperación es Válido
userSchema.methods.isResetTokenValid = function () {
  return this.passwordResetToken && this.passwordResetExpires > Date.now()
}
//Método para Limpiar Token de Recuperación Después de Usarlo
userSchema.methods.clearResetToken = async function () {
  this.passwordResetToken = undefined
  this.passwordResetExpires = undefined
  await this.save({ validateBeforeSave: false })
}

//Método para Verificar Si el Usuario Cambió su Email
userSchema.methods.hasChangedEmail = function (oldEmail) {
  return this.email !== oldEmail
}

// 🔹 Manejo de errores de índice duplicado
// ✅ Versión más robusta del post-save hook
userSchema.post('save', function (error, doc, next) {
  if (error.name === 'MongoServerError' && error.code === 11000) {
    const duplicateKey = Object.keys(error.keyValue)[0]
    let errorMessage = ''
    if (duplicateKey === 'email') {
      errorMessage = 'Email ya registrado.'
    } else if (duplicateKey === 'mobile') {
      errorMessage = 'Móvil ya registrado.'
    } else {
      errorMessage = `El campo ${duplicateKey} ya existe.`
    }
    next(new Error(errorMessage))
  } else {
    next(error)
  }
})

userSchema.methods.toggleBlock = async function () {
  const previousState = this.isBlocked
  this.isBlocked = !previousState
  if (previousState !== this.isBlocked) {
    await this.save({ validateBeforeSave: false })
  }
  return this.isBlocked
}

if (mongoose.models.User) {
  delete mongoose.models.User
}


const User = mongoose.model('User', userSchema)
export default User