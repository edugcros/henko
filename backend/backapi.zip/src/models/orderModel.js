// 📁 src/models/orderModel.js
import mongoose from 'mongoose'

const { Schema } = mongoose

// Subdocumento de productos de la orden
const orderProductSchema = new Schema(
  {
    product: {
      type: Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'Referencia del producto es obligatoria'],
    },
    count: {
      type: Number,
      required: [true, 'La cantidad es obligatoria'],
      min: [1, 'La cantidad mínima es 1'],
    },
    color: {
      type: Schema.Types.ObjectId,
      ref: 'Color',
      default: null,
    },
    price: {
      type: Schema.Types.Decimal128,
      required: [true, 'El precio unitario es obligatorio'],
      min: 0,
    },
    subtotal: {
      type: Schema.Types.Decimal128,
      required: [true, 'El subtotal es obligatorio'],
      min: 0,
    },
  },
  { _id: false, toJSON: { virtuals: true }, toObject: { virtuals: true } },
)

// Virtual para obtener subtotal en centavos
orderProductSchema.virtual('subtotalCents').get(function () {
  return Math.round(parseFloat(this.subtotal.toString()) * 100)
})

// Schema principal de órdenes
const orderSchema = new Schema(
  {
    products: {
      type: [orderProductSchema],
      validate: {
        validator: arr => Array.isArray(arr) && arr.length > 0,
        message: 'La orden debe contener al menos un producto',
      },
    },
    paymentIntent: {
      id: { type: String, required: [true, 'El ID de pago es obligatorio'] },
      status: {
        type: String,
        required: [true, 'El estado del pago es obligatorio'],
        enum: ['pending', 'completed', 'failed'],
        lowercase: true,
      },
      method: {
        type: String,
        required: [true, 'El método de pago es obligatorio'],
        enum: ['credit card', 'paypal', 'bank transfer', 'cash on delivery'],
        lowercase: true,
      },
      currency: {
        type: String,
        default: 'ARS',
        uppercase: true,
      },
      amount: {
        type: Schema.Types.Decimal128,
        required: [true, 'El monto de pago es obligatorio'],
        min: 0,
      },
      reference: { type: String }, // ID de transacción externa opcional
    },
    orderStatus: {
      type: String,
      default: 'not processed',
      enum: [
        'not processed',
        'cash on delivery',
        'processing',
        'dispatched',
        'cancelled',
        'delivered',
        'refunded',
      ],
      lowercase: true,
      index: true,
    },
    orderby: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'La orden debe estar asociada a un usuario'],
      index: true,
    },
    isDeleted: { type: Boolean, default: false, index: true },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } },
)

// Índices
orderSchema.index({ orderby: 1, createdAt: -1 })
orderSchema.index(
  { 'paymentIntent.id': 1, orderby: 1 },
  { unique: true, partialFilterExpression: { isDeleted: false } },
)

// Métodos de utilidad
orderSchema.methods.isPaid = function () {
  return this.paymentIntent.status === 'completed'
}

orderSchema.methods.getTotalAmount = function () {
  return this.products.reduce(
    (acc, p) => acc + parseFloat(p.subtotal.toString()),
    0,
  )
}

// Método para actualizar estado con rollback de stock
orderSchema.methods.updateStatus = async function (nextStatus) {
  const Product = mongoose.model('Product')
  const prevStatus = this.orderStatus
  this.orderStatus = nextStatus

  if (['cancelled', 'refunded'].includes(nextStatus) && !['cancelled', 'refunded'].includes(prevStatus)) {
    for (const p of this.products) {
      await Product.updateOne(
        { _id: p.product, isDeleted: false },
        { $inc: { quantity: +p.count, sold: -p.count } },
      )
    }
  }
  await this.save()
  return this
}

const Order = mongoose.model('Order', orderSchema)
export default Order
