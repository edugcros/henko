import mongoose from 'mongoose'

const onboardingSuggestionSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Users',
      required: [true, 'El usuario es obligatorio'],
      index: true,
    },
    name: {
      type: String,
      required: [true, 'El nombre es obligatorio'],
      trim: true,
      minlength: [3, 'El nombre debe tener al menos 3 caracteres'],
      maxlength: [100, 'El nombre no puede superar los 100 caracteres'],
    },
    categories: {
      type: [String],
      default: [],
      validate: {
        validator: function (arr) {
          return Array.isArray(arr) && arr.some(c => c && c.trim().length > 0)
        },
        message: 'Debe incluir al menos una categoría válida',
      },
      set: arr => arr.map(c => c.trim()).filter(Boolean),
    },
    logo: {
      type: String,
      default: null,
      validate: {
        validator: function (v) {
          if (!v) return true
          return /^https?:\/\/.+\.(jpg|jpeg|png|svg|webp)$/i.test(v)
        },
        message: 'La URL del logo no es válida',
      },
    },
    status: {
      type: String,
      enum: ['draft', 'applied', 'archived'],
      default: 'draft',
      index: true,
    },
    appliedToStore: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
)

// Método para verificar si la sugerencia es editable
onboardingSuggestionSchema.methods.isEditable = function () {
  return this.status === 'draft'
}

// Índice compuesto útil para búsquedas de usuario y estado
onboardingSuggestionSchema.index({ user: 1, status: 1 })

const OnboardingSuggestion = mongoose.model('OnboardingSuggestion', onboardingSuggestionSchema)

export default OnboardingSuggestion
