import mongoose from 'mongoose'

const imageSchema = new mongoose.Schema({
  public_id: { type: String, required: true },
  url: { type: String, required: true },
}, { _id: false })

const ratingSchema = new mongoose.Schema({
  star: {
    type: Number,
    required: true,
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5'],
  },
  comment: { type: String, trim: true },
  postedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
}, { timestamps: true })

const productSchema = new mongoose.Schema({
  tenantId: {
    type: String,
    required: [true, 'Tenant ID is required'],
    index: true,
  },
  title: {
    type: String,
    required: [true, 'Product title is required'],
    trim: true,
  },
  marca: {
    type: String,
    required: [true, 'Product brand is required'],
    trim: true,
  },
  color: {
    type: [String],
    default: [],
    validate: {
      validator: arr => arr.every(c => typeof c === 'string'),
      message: 'Each color must be a string',
    },
  },
  size: { type: String, trim: true },
  gender: { type: String, enum: ['Hombre', 'Mujer', 'Niño'] },
  slug: {
    type: String,
    lowercase: true,
    required: true,
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
    trim: true,
  },
  categoria: {
    type: String,
    required: [true, 'Category is required'],
    trim: true,
    index: true,
  },
  subcategoria: {
    type: String,
    required: [true, 'Subcategory is required'],
    trim: true,
  },
  atributos: {
    type: mongoose.Schema.Types.Mixed,
    default: {},
  },
  tags: {
    type: [String],
    default: [],
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price must be non-negative'],
  },
  stock: {
    type: Number,
    default: 0,
    min: [0, 'Stock cannot be negative'],
  },
  currency: {
    type: String,
    default: 'ARS',
    uppercase: true,
  },
  colorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Color', required: false },

  condicion: {
    type: String,
    enum: ['nuevo', 'usado'],
    default: 'nuevo',
  },
  images: { type: [imageSchema], default: [] },
  ratings: { type: [ratingSchema], default: [] },
  totalrating: { type: Number, default: 0 },

  
  // === IA / Generación automática ===
  iaGenerated: { type: Boolean, default: false },
  iaSource: {
    type: String,
    enum: ['blip', 'clip', 'llm', 'manual', 'blip+clip', null],
    default: null,
  },
  validado: { type: Boolean, default: false },
  visual_info: { type: mongoose.Schema.Types.Mixed, default: {} },
  llm_metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  embeddings: {
    type: [Number],
    default: [],
    validate: {
      validator: function(arr) {
        // Si el array no está vacío, debe tener exactamente 768 dimensiones (estándar de Gemini)
        return arr.length === 0 || arr.length === 768
      },
      message: 'Embedding must be 768 dimensions',
    },
  },
}, { timestamps: true })

// === Hooks / Middleware ===

// Normalizar tags y color
productSchema.pre('save', function (next) {
  if (Array.isArray(this.tags))
    this.tags = [...new Set(this.tags.map(t => t.trim().toLowerCase()))]

  if (Array.isArray(this.color))
    this.color = [...new Set(this.color.map(c => c.trim().toLowerCase()))]

  next()
})

// Calcular totalrating promedio
productSchema.pre('save', function (next) {
  if (this.ratings?.length) {
    const total = this.ratings.reduce((sum, r) => sum + (r.star || 0), 0)
    this.totalrating = Math.round((total / this.ratings.length) * 10) / 10
  } else {
    this.totalrating = 0
  }
  next()
})

// Índices compuestos para optimizar búsquedas IA o admin
productSchema.index(
  { tenantId: 1, slug: 1 },
  { unique: true },
)


const Product = mongoose.model('Product', productSchema)
export default Product
