import mongoose from 'mongoose'
import sanitizeHtml from 'sanitize-html'

const enqSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters long'],
      maxlength: [50, 'Name cannot exceed 50 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      lowercase: true,
      trim: true,
      validate: {
        validator: v =>
          /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v),
        message: props => `${props.value} is not a valid email!`,
      },
    },
    mobile: {
      type: String,
      required: [true, 'Mobile number is required'],
      validate: {
        validator: v => /^\+?[1-9]\d{1,14}$/.test(v),
        message: props => `${props.value} is not a valid phone number!`,
      },
    },
    comment: {
      type: String,
      required: [true, 'Comment is required'],
      minlength: [10, 'Comment must be at least 10 characters long'],
      maxlength: [500, 'Comment cannot exceed 500 characters'],
      validate: {
        validator: v => v && v.trim().length >= 10,
        message: 'Comment must be meaningful and at least 10 characters',
      },
    },
    status: {
      type: String,
      default: 'Submitted',
      enum: ['Submitted', 'Contacted', 'In Progress', 'Resolved', 'Closed'],
    },
  },
  { timestamps: true },
)

// Sanitizar comentario antes de guardar
enqSchema.pre('save', function (next) {
  if (this.isModified('comment')) {
    this.comment = sanitizeHtml(this.comment, {
      allowedTags: [],
      allowedAttributes: {},
    })
  }
  next()
})

const Enquiry = mongoose.model('Enquiry', enqSchema)
export default Enquiry
