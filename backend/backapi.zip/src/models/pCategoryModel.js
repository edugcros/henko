import mongoose from 'mongoose'

const pCategorySchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Category title is required'],
      unique: true,
      index: true,
      trim: true,
      minlength: [3, 'Category title must be at least 3 characters long'],
      maxlength: [50, 'Category title cannot exceed 50 characters'],
      validate: {
        validator: function (v) {
          return /^[A-Za-z0-9 ]+$/.test(v)
        },
        message: props =>
          `${props.value} is not a valid category name! Only letters, numbers, and spaces are allowed.`,
      },
    },
    description: {
      type: String,
      trim: true,
      maxlength: [200, 'Description cannot exceed 200 characters'],
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  },
)

const PCategory = mongoose.models.PCategory || mongoose.model('PCategory', pCategorySchema)

export default PCategory
