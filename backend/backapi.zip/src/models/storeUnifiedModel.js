import mongoose from 'mongoose'

// ---------- Store (Tienda) ----------
const storeSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true, unique: true },
    name: { type: String, required: true, trim: true },
    description: { type: String, default: '', trim: true },
    logo: { type: String, default: null },
    initializedFromAI: { type: Boolean, default: false },
    status: { type: String, enum: ['draft', 'active', 'disabled'], default: 'draft' },
    domain: { type: String, default: null },
    theme: { type: String, enum: ['default', 'modern', 'minimal', 'classic'], default: 'default' },
    settings: {
      colors: { primary: { type: String, default: '#000000' }, secondary: { type: String, default: '#ffffff' } },
      currency: { type: String, default: 'ARS' },
    },
  },
  { timestamps: true },
)

// ---------- StoreDesign (Diseño de Tienda) ----------
const sectionSchema = new mongoose.Schema({
  type: { type: String, required: true },
  order: { type: Number, default: 0 },
  config: { type: mongoose.Schema.Types.Mixed, default: {} },
})

const storeDesignSchema = new mongoose.Schema(
  {
    storeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Store', required: true, unique: true, index: true },
    primaryColor: { type: String, default: '#10D1B2' },
    secondaryColor: { type: String, default: '#03253A' },
    logo: { type: String, default: null },
    headerType: { type: String, enum: ['simple', 'centered', 'withSearch'], default: 'simple' },
    homeSections: { type: [sectionSchema], default: [] },
    showSlider: { type: Boolean, default: true },
    font: { type: String, default: 'Montserrat, Arial, sans-serif' },
    footerType: { type: String, enum: ['simple', 'detailed'], default: 'simple' },
    customCSS: { type: String, default: '' },
    customJS: { type: String, default: '' },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Users' },
  },
  { timestamps: true },
)

export const Store = mongoose.model('Store', storeSchema)
export const StoreDesign = mongoose.model('StoreDesign', storeDesignSchema)
