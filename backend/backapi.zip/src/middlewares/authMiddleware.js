import jwt from 'jsonwebtoken'
import asyncHandler from 'express-async-handler'
import logger from '../../config/logger.js'
import mongoose from 'mongoose'

const parseBearer = req => {
  const h = req.headers?.authorization
  if (!h) return null
  const [type, token] = h.split(' ')
  return type?.toLowerCase() === 'bearer' ? token : null
}

export const authMiddleware = asyncHandler(async (req, res, next) => {
  const token = parseBearer(req) || req.cookies?.token
  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acceso ausente' })
  }
  console.log(token)
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET, {
      algorithms: ['HS256'],
    })

    if (!mongoose.Types.ObjectId.isValid(decoded.sub)) {
      return res.status(400).json({ success: false, message: 'ID de usuario inválido en token' })
    }

    req.user = {
      id: decoded.sub,
      _id: decoded.sub,
      role: decoded.role,
      tenantId: decoded.tenantId,
    }

    next()
  } catch (err) {
    logger.warn(`JWT inválido o expirado: ${err.message}`)
    return res.status(401).json({ success: false, message: 'Token inválido o expirado' })
  }

})

export const allowRoles = (...roles) =>
  asyncHandler(async (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, message: 'No autenticado' })
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Permisos insuficientes' })
    }
    next()
  })

export const isAdmin = allowRoles('admin')
