// 📁 src/middlewares/csrfMiddleware.js
import csurf from 'csurf'
import logger from '../../config/logger.js'

// 🔹 Middleware dinámico para detectar ngrok por request
export const detectNgrok = (req, res, next) => {
  const host = req.get('host') || ''
  req.isNgrok = host.includes('ngrok-free') || host.includes('ngrok.app')
  next()
}

// 🔹 CSRF Protection usando detección dinámica
export const csrfProtection = csurf({
  cookie: {
    key: '_csrf',
    httpOnly: true,
    secure: false,        // se sobreescribe dinámicamente en attachCsrfToken
    sameSite: 'Lax',      // idem
    path: '/',
  },
})

// 🔹 Genera token y lo expone seguro para frontend
export const attachCsrfToken = (req, res, next) => {
  try {
    const token = req.csrfToken()
    const isProd = process.env.NODE_ENV === 'production' && !req.isNgrok

    res.cookie('X-CSRF-Token', token, {
      httpOnly: false,                // accesible en frontend
      secure: isProd,                 // solo en prod real
      sameSite: isProd ? 'None' : 'Lax',
      path: '/',
      maxAge: 15 * 60 * 1000,         // 15 minutos
    })

    res.setHeader('x-csrf-token', token)

    logger.silly(`CSRF generated: ${token.substring(0, 8)}... for ${req.path}`)
    next()
  } catch (err) {
    logger.error('Error generando CSRF token: ' + err.message)
    return res.status(500).json({ success: false, message: 'Error generando CSRF' })
  }
}

// 🔹 Endpoint utilitario para obtener token vía AJAX
export const sendCsrfToken = (req, res) => {
  try {
    const token = req.csrfToken()
    return res.status(200).json({ success: true, csrfToken: token })
  } catch (err) {
    logger.error('Error sendCsrfToken: ' + err.message)
    return res.status(500).json({ success: false, message: 'Error CSRF' })
  }
}

// 🔹 Helper de logging
export const logCsrf = (req, res, next) => {
  logger.debug(
    `CSRF cookies: _csrf=${req.cookies?._csrf ? 'yes' : 'no'} | X-CSRF-Token cookie: ${req.cookies?.['X-CSRF-Token'] ? 'yes' : 'no'} | header: ${req.headers['x-csrf-token'] ? 'yes' : 'no'} | isNgrok=${req.isNgrok}`,
  )
  next()
}
