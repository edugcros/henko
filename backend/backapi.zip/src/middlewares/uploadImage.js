// src/middlewares/uploadImage.js

import multer from 'multer'
import sharp from 'sharp'
/*import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import logger from '../../config/logger.js';*/

// 📁 src/middlewares/uploadImage.js — Validación MIME/size + resize + sanitizado

const MAX_SIZE_MB = Number(process.env.MAX_IMAGE_MB || 5)
const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024
const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/avif'])

const sanitizeName = name => {
  const base = String(name || 'image').toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9_.-]/g, '')
    .replace(/-+/g, '-')
    .slice(0, 64) || 'image'
  return base
}

const storage = multer.memoryStorage()

const fileFilter = (_req, file, cb) => {
  if (!ALLOWED_MIME.has(file.mimetype)) {
    return cb(new Error('Formato no permitido (jpg, png, webp, avif)'))
  }
  cb(null, true)
}

export const uploadPhoto = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_SIZE_BYTES },
})

export const productImgResize = async (req, res, next) => {
  try {
    if (!req.file?.buffer) return res.status(400).json({ success: false, message: 'No se envió imagen' })
    const safeBase = sanitizeName(req.file.originalname?.split('.').slice(0, -1).join('.') || 'image')
    const processed = await sharp(req.file.buffer)
      .rotate()
      .resize({ width: 1600, withoutEnlargement: true })
      .webp({ quality: 80 })
      .toBuffer()
    req.file.processedBuffer = processed
    req.file.safeName = `${Date.now()}-${safeBase}.webp`
    next()
  } catch (err) {
    next(err)
  }
}
