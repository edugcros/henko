import asyncHandler from 'express-async-handler'
import { sendEmail } from '../utils/sendEmail.js'
import logger from '../../config/logger.js'
import validator from 'validator'

// Controlador para envío de correos
export const sendEmailController = asyncHandler(async (req, res) => {
  let { to, subject, text, html } = req.body

  // Validaciones
  if (!to || !validator.isEmail(to)) {
    return res.status(400).json({ success: false, message: 'Destinatario inválido' })
  }
  if (!subject || subject.trim().length < 3) {
    return res.status(400).json({ success: false, message: 'El asunto debe tener al menos 3 caracteres' })
  }
  if (!text && !html) {
    return res.status(400).json({ success: false, message: 'Debe proporcionar contenido en texto o HTML' })
  }

  // Log del intento de envío
  logger.info(`Enviando correo a ${to} con asunto "${subject}"`)

  // Sanitizar HTML si existe
  if (html) {
    html = validator.escape(html)
  }

  // Enviar correo
  const result = await sendEmail({ to, subject: subject.trim(), text, html })

  logger.info(`Correo enviado exitosamente a ${to}`)
  res.status(200).json({
    success: true,
    message: 'Correo enviado correctamente',
    data: result,
  })
})
