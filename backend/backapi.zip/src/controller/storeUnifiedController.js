import { Store, StoreDesign } from '../models/storeUnifiedModel.js'
import { respondSuccess, respondError } from '../utils/response.js'
import asyncHandler from 'express-async-handler'
import mongoose from 'mongoose'

// ------ TIENDA ------
// GET /api/store/my-stores
export const getMyStores = asyncHandler(async (req, res) => {
  const stores = await Store.find({ owner: req.user._id })
  respondSuccess(res, 200, 'Tiendas del usuario', stores)
})

// POST /api/store/
export const createStore = asyncHandler(async (req, res) => {
  const { name, description, logo } = req.body
  const exist = await Store.findOne({ owner: req.user._id })
  if (exist) return respondError(res, 400, 'Ya tienes una tienda creada')
  const store = await Store.create({
    owner: req.user._id,
    name,
    description,
    logo,
    status: 'active',
  })
  respondSuccess(res, 201, 'Tienda creada', store)
})

// ------ DISEÑO DE TIENDA ------
// GET /api/store-design/:storeId
export const getStoreDesign = asyncHandler(async (req, res) => {
  const { storeId } = req.params
  if (!mongoose.Types.ObjectId.isValid(storeId)) {
    return respondError(res, 400, 'storeId inválido')
  }
  const design = await StoreDesign.findOne({ storeId })
  if (!design) {
    return respondSuccess(res, 200, 'No hay diseño, devolviendo default', {
      storeId,
      primaryColor: '#10D1B2',
      secondaryColor: '#03253A',
      logo: null,
      headerType: 'simple',
      homeSections: [],
      showSlider: true,
      font: 'Montserrat, Arial, sans-serif',
      footerType: 'simple',
      customCSS: '',
      customJS: '',
    })
  }
  respondSuccess(res, 200, 'OK', design)
})

// POST /api/store-design/:storeId
export const saveStoreDesign = asyncHandler(async (req, res) => {
  const { storeId } = req.params
  if (!mongoose.Types.ObjectId.isValid(storeId)) {
    return respondError(res, 400, 'storeId inválido')
  }
  const payload = req.body
  let design = await StoreDesign.findOne({ storeId })
  if (design) {
    Object.assign(design, payload)
    design.updatedBy = req.user?._id
    await design.save()
    return respondSuccess(res, 200, 'Diseño actualizado', design)
  }
  design = await StoreDesign.create({ storeId, ...payload, updatedBy: req.user?._id })
  respondSuccess(res, 201, 'Diseño creado', design)
})

// DELETE /api/store-design/:storeId
export const deleteStoreDesign = asyncHandler(async (req, res) => {
  const { storeId } = req.params
  if (!mongoose.Types.ObjectId.isValid(storeId)) {
    return respondError(res, 400, 'storeId inválido')
  }
  await StoreDesign.deleteOne({ storeId })
  respondSuccess(res, 200, 'Diseño eliminado')
})
