import User from '../models/userModel.js'
import Product from '../models/productModel.js'
import Cart from '../models/cartModel.js'
import Coupon from '../models/couponModel.js'
import expressAsyncHandler from 'express-async-handler'
import { validateMongoDbIdMiddleware } from '../utils/validation.js'
import jwt from 'jsonwebtoken'
import { body, validationResult } from 'express-validator'
import rateLimit from 'express-rate-limit'
import crypto from 'crypto'
import bcrypt from 'bcrypt'
import { generateAccessToken } from '../../config/generateAccessToken.js'
import { generateRefreshToken } from '../../config/generateRefreshToken.js'
import { sendEmail } from '../utils/sendEmail.js'
import logger from '../../config/logger.js'
import process from 'process'
import { sendResponse } from '../utils/response.js'
import mongoose from 'mongoose'


// --- Middleware/Utilidades de Seguridad Reutilizables ---
const isProd = process.env.NODE_ENV === 'production'

// Opciones centralizadas de cookie
const getCookieOptions = maxAgeMs => ({
  httpOnly: true,
  secure: isProd,               // true en producción HTTPS
  sameSite: 'None',             // necesario para cross-site (ngrok / mobile)
  path: '/',
  maxAge: typeof maxAgeMs === 'number' ? maxAgeMs : undefined,
})

// --- Helpers internos ---
const headerCsrf = req => {
  // csurf genera el token, front debe enviar por header x-csrf-token (case-insensitive)
  return req.headers['x-csrf-token'] || req.headers['X-CSRF-Token'] || req.headers['X-Csrf-Token']
}

// --- GET: /api/user/csrf-token ---
export const getCsrfToken = expressAsyncHandler(async (req, res) => {
  try {
    const csrfToken = req.csrfToken()
    // Cookie para front (legible por JS si necesitás, aquí la ponemos httpOnly:false para compatibilidad con algunos front)
    res.cookie('X-CSRF-Token', csrfToken, {
      httpOnly: false,
      secure: isProd,
      sameSite: 'None',
      path: '/',
      maxAge: 15 * 60 * 1000,
    })

    // también devolvemos JSON con token
    return res.status(200).json({ success: true, csrfToken: csrfToken })
  } catch (err) {
    logger.error('getCsrfToken error: ' + err.message)
    return sendResponse(res, 500, false, 'No se pudo generar token CSRF')
  }
})

// 🧙 Crear nuevo usuario
export const createUser = [
  // ---------- Validaciones ----------
  body('email').isEmail().withMessage('Correo inválido').normalizeEmail(),
  body('password').isLength({ min: 8 }).withMessage('La contraseña debe tener al menos 8 caracteres').trim().escape(),
  body('firstname').notEmpty().withMessage('El nombre es obligatorio').trim().escape(),
  body('lastname').notEmpty().withMessage('El apellido es obligatorio').trim().escape(),
  body('mobile').isMobilePhone().withMessage('Número de móvil inválido').trim().escape(),
    
  expressAsyncHandler(async (req, res) => {
    // ---------- Validación de express-validator ----------
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map(err => err.msg)
      return sendResponse(res, 400, false, 'Error de validación', errorMessages)
    }

    // ---------- Obtener y validar tenant ----------
    const tenantId = req.headers['x-tenant-id']
    if (!tenantId) {
      return sendResponse(res, 400, false, 'Falta el tenantId en la cabecera')
    }

    // Desestructuración explícita para sanitizar/seleccionar campos
    const { email, password, firstname, lastname, mobile } = req.body

    // ---------- Prevenir rol manual (Mejora de seguridad) ----------
    if (req.body.role && req.body.role !== 'user') {
      return sendResponse(res, 403, false, 'No puedes asignarte un rol diferente al registrarte.')
    }

    // ---------- Verificar usuario existente ----------
    const existingUser = await User.findOne({ email, tenantId })
    if (existingUser) {
      return sendResponse(res, 409, false, 'El usuario ya existe en este tenant')
    }

    // ---------- Hash password ----------
    const hashedPassword = await bcrypt.hash(password, 10)

    const newUserData = {
      email,
      password: hashedPassword,
      firstname,
      lastname,
      mobile,
      role: 'user',
      tenantId,
    }

    // ---------- Crear usuario ----------
    const newUser = await User.create(newUserData)

    // ---------- Mail de bienvenida (Asíncrono y no bloqueante) ----------
    try {
      await sendEmail({
        to: email,
        subject: 'Bienvenido a nuestra plataforma',
        text: `Hola ${firstname}, gracias por registrarte.`,
        html: `<h1>Hola ${firstname}</h1><p>Gracias por registrarte en nuestra plataforma.</p>`,
      })
      logger.info(`📧 Correo de bienvenida enviado a ${email}`)
    } catch (error) {
      // Solo log, no se devuelve error al cliente por fallar el correo
      logger.error(`❌ Error al enviar correo de bienvenida: ${error.message}`)
    }

    logger.info(`👤 Usuario creado: ${newUser.email} | Tenant: ${tenantId}`)

    return sendResponse(res, 201, true, 'Usuario creado correctamente', {
      id: newUser.id,
      email: newUser.email,
      firstname: newUser.firstname,
      lastname: newUser.lastname,
      mobile: newUser.mobile,
      tenantId,
    })
  }),
]

// 🔐 Login de usuario o admin
// Asume expressAsyncHandler, logger, User, generateRefreshToken, generateAccessToken, sendResponse, bcrypt ya importados arriba
const loginHandler = expressAsyncHandler(async (req, res, isAdmin = false) => {
  const { email, password } = req.body

  if (!email || !password) {
    return sendResponse(res, 400, false, 'Correo y contraseña son obligatorios')
  }

  // --- OPTIONAL: sólo logging — NO usar para validación estricta ---
  // CSRF header validation: comparar token de header con cookie X-CSRF-Token (opcionalmente con _csrf)
  const csrfHeader = headerCsrf(req)
  const csrfCookie = req.cookies && (req.cookies['X-CSRF-Token'] || req.cookies['_csrf'])

  if (!csrfHeader || csrfHeader !== csrfCookie) {
    logger.warn(`🔐 CSRF token inválido para login de ${email} | header:${!!csrfHeader} cookie:${!!csrfCookie}`)
    return sendResponse(res, 403, false, 'Token CSRF inválido o ausente')
  }
  // Buscar usuario (incluimos password y refreshToken)
  const user = await User.findOne({ email }).select('+password +refreshToken +failedLoginAttempts +isBlocked +blockedUntil')
  if (!user || (isAdmin && user.role !== 'admin')) {
    logger.warn(`🚫 Acceso denegado para: ${email}`)
    // evitar revelar si email existe
    return sendResponse(res, 401, false, 'Credenciales inválidas')
  }

  // Bloqueo temporal
  if (user.isBlocked) {
    if (user.blockedUntil && user.blockedUntil > new Date()) {
      const minutesLeft = Math.ceil((user.blockedUntil - Date.now()) / 60000)
      logger.warn(`🔒 Cuenta bloqueada temporalmente: ${email}`)
      return sendResponse(res, 403, false, `Cuenta bloqueada temporalmente. Intente en ${minutesLeft} minutos.`)
    }
    // bloqueo expirado -> resetear en DB
    if (user.blockedUntil && user.blockedUntil <= new Date()) {
      await User.findByIdAndUpdate(user._id, { isBlocked: false, failedLoginAttempts: 0, blockedUntil: null }, { validateBeforeSave: false })
      user.isBlocked = false
      user.failedLoginAttempts = 0
      user.blockedUntil = null
    }
  }

  const isPasswordValid = await user.isPasswordMatched(password)
  if (!isPasswordValid) {
    const newAttempts = (user.failedLoginAttempts || 0) + 1
    const MAX = Number(process.env.MAX_LOGIN_ATTEMPTS) || 5
    const BLOCK_MINUTES = Number(process.env.BLOCK_MINUTES) || 15

    const update = { failedLoginAttempts: newAttempts }
    if (newAttempts >= MAX) {
      update.isBlocked = true
      update.blockedUntil = new Date(Date.now() + BLOCK_MINUTES * 60 * 1000)
    }

    await User.findByIdAndUpdate(user._id, update, { validateBeforeSave: false })
    logger.warn(`❌ Intento de login fallido para: ${email} (intentos=${newAttempts})`)
    if (newAttempts >= MAX) {
      return sendResponse(res, 403, false, `Demasiados intentos fallidos. Cuenta bloqueada ${BLOCK_MINUTES} minutos.`)
    }
    return sendResponse(res, 401, false, 'Credenciales inválidas')
  }

  // Login válido: resetear contador
  await User.findByIdAndUpdate(user._id, { failedLoginAttempts: 0, isBlocked: false, blockedUntil: null }, { validateBeforeSave: false })

  // Generar tokens
  const accessToken = generateAccessToken(user._id, { role: user.role, tenantId: user.tenantId })
  const { refreshToken, hashedToken } = await generateRefreshToken(user._id)

  // --- IMPORTANTE: guardar el hashedToken tal cual (NO re-hashear) ---
  await User.findByIdAndUpdate(user._id, { refreshToken: hashedToken }, { validateBeforeSave: false })

  // Cookies
  const refreshCookieOptions = getCookieOptions(3 * 24 * 60 * 60 * 1000) // 3 días
  const accessCookieOptions = getCookieOptions(15 * 60 * 1000)

  // setear cookies (front debe usar withCredentials:true)
  res.cookie('refreshToken', refreshToken, refreshCookieOptions)
  res.cookie('token', accessToken, accessCookieOptions)

  logger.info(`✅ Login exitoso: ${email}`)

  /*const safeUser = typeof user.toSafeObject === 'function' ? user.toSafeObject() : {
    _id: user._id,
    email: user.email,
    firstname: user.firstname,
    lastname: user.lastname,
    role: user.role,
    tenantId: user.tenantId,
    wishlist: user.wishlist || [],
  }*/

  return res.status(200).json({
    success: true,
    data: {
      user: {
        ...user.toSafeObject(),
        tenantId: user.tenantId,
      },
      token: accessToken,
      refreshToken: refreshToken,
    },
  })

})
export const loginUser = (req, res) => loginHandler(req, res, false) 
export const loginAdmin = (req, res) => loginHandler(req, res, true)

// CurrentUser
export const getCurrentUser = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id || req.user?._id
  if (!userId) {
    return res.status(401).json({ success: false, message: 'Usuario no autenticado' })
  }

  const user = await User.findById(userId)
  if (!user) {
    return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
  }
  return sendResponse(res, 200, true, 'Usuario actual obtenido', user.toSafeObject())
})

// 📌 /controllers/authCtrl.js

export const handleRefreshToken = expressAsyncHandler(async (req, res) => {
  // ---------------------------------------------------------
  // 1) CSRF mínimo: exigimos x-csrf-token en header
  // ---------------------------------------------------------
  const csrfHeader = req.headers['x-csrf-token']
  if (!csrfHeader) {
    logger.warn('⛔ CSRF token ausente en refresh')
    return res.status(403).json({ success: false, message: 'CSRF requerido' })
  }

  // ---------------------------------------------------------
  // 2) Leer refresh token desde cookie
  // ---------------------------------------------------------
  const refreshToken = req.cookies?.refreshToken
  if (!refreshToken || refreshToken === 'undefined') {
    logger.warn('⚠️ No hay refresh token en las cookies')
    return res.status(403).json({ success: false, message: 'No hay token de refresco' })
  }

  // ---------------------------------------------------------
  // 3) Verificar firma JWT del refresh token
  // ---------------------------------------------------------
  let decoded
  try {
    decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET)
  } catch (err) {
    logger.warn('❌ Refresh token inválido o expirado', err)
    return res.status(403).json({ success: false, message: 'Token inválido o expirado' })
  }

  // El campo sub/id viene del loginHandler
  const userId = decoded.sub || decoded.id

  // ---------------------------------------------------------
  // 4) Buscar usuario y obtener hash del refresh guardado
  // ---------------------------------------------------------
  const user = await User.findById(userId).select('+refreshToken')
  if (!user || !user.refreshToken) {
    logger.warn('🚫 Usuario no válido o sin refresh token almacenado')
    return res.status(403).json({ success: false, message: 'Usuario inválido' })
  }

  // ---------------------------------------------------------
  // 5) Comparar refreshToken recibido contra el hash
  // ---------------------------------------------------------
  const isValid = await bcrypt.compare(refreshToken, user.refreshToken)
  if (!isValid) {
    logger.warn(`🚨 Refresh token no coincide para ${user.email}`)
    await User.findByIdAndUpdate(
      user._id,
      { refreshToken: null },
      { validateBeforeSave: false },
    )
    return res.status(403).json({ success: false, message: 'Token de refresco no válido' })
  }

  // ---------------------------------------------------------
  // 6) Generar nuevo Access Token + nuevo Refresh Token
  // ---------------------------------------------------------
  const newAccessToken = generateAccessToken(user._id, {
    role: user.role,
    tenantId: user.tenantId,
  })

  const { refreshToken: newRefreshToken, hashedToken } = await generateRefreshToken(user._id)

  // Guardar hash nuevo (NO re-hashear)
  await User.findByIdAndUpdate(
    user._id,
    { refreshToken: hashedToken },
    { validateBeforeSave: false },
  )

  // ---------------------------------------------------------
  // 7) Setear cookies (centralizado, coherente con login)
  // ---------------------------------------------------------
  const cookieOptions = {
    httpOnly: true,
    secure: true,
    sameSite: 'None',
    path: '/',
  }

  res.cookie('refreshToken', newRefreshToken, { ...cookieOptions, maxAge: 3 * 24 * 60 * 60 * 1000 }) // 3 días  
  res.cookie('token', newAccessToken, { ...cookieOptions, maxAge: 15 * 60 * 1000 }) // 15 minutos

  logger.info(`🔄 Tokens renovados para ${user.email}`)

  return res.status(200).json({
    success: true,
    data: {
      user: {
        ...user.toSafeObject(),
        tenantId: user.tenantId,
      },
      token: newAccessToken,
    },
  })
})



// 🔒 Logout seguro
export const logout = expressAsyncHandler(async (req, res) => {
  const csrfHeader = req.headers['x-csrf-token']
  const csrfCookie = req.cookies['X-CSRF-Token']
  const refreshToken = req.cookies?.refreshToken

  // Validación CSRF
  if (!csrfHeader || csrfHeader !== csrfCookie) {
    logger.warn('❌ CSRF Token inválido durante logout')
    return res.status(403).json({ success: false, message: 'Token CSRF inválido o ausente' })
  }

  // Helper centralizado
  const clearAllAuthCookies = res => {
    const opts = { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'Strict', path: '/' }
    res.clearCookie('refreshToken', opts)
    res.clearCookie('token', opts)
    res.clearCookie('X-CSRF-Token', { ...opts, httpOnly: false })
    res.clearCookie('_csrf', opts)
    return res
  }

  // Intentar invalidar refresh token
  try {
    const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, {
      algorithms: ['HS256'],
    })

    const user = await User.findById(decoded.sub).select('+refreshToken')
    if (user) {
      user.refreshToken = null
      await user.save({ validateBeforeSave: false })
      logger.info(`👋 Logout exitoso: ${user.email}`)
    }
  } catch (err) {
    logger.warn('❌ Refresh token inválido o expirado en logout', err.message)
  }


  // Limpiar cookies siempre
  clearAllAuthCookies(res)

  return res.status(200).json({
    success: true,
    message: 'Sesión cerrada correctamente',
  })
})


// ✅ Actualizar contraseña
export const updatePassword = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id || req.user?._id
  const { currentPassword, newPassword } = req.body

  if (!currentPassword || !newPassword) {
    return sendResponse(res, 400, false, 'Ambas contraseñas son necesarias')
  }

  // Validación de ID (asumiendo que validateMongoDbIdMiddleware lanza si es inválido)
  validateMongoDbIdMiddleware(userId) 

  // Seleccionar el campo 'password' para la comparación
  const user = await User.findById(userId).select('+password')
  if (!user) {
    logger.warn('⚠️ Usuario no encontrado al intentar actualizar contraseña')
    return sendResponse(res, 404, false, 'Usuario no encontrado')
  }

  const isMatch = await user.isPasswordMatched(currentPassword)
  if (!isMatch) {
    logger.warn(`❌ Contraseña actual incorrecta para usuario ${user.email}`)
    return sendResponse(res, 400, false, 'La contraseña actual es incorrecta')
  }

  // Si la contraseña actual es correcta, actualizamos la contraseña con la nueva
  user.password = newPassword // Mongoose hook pre-save hasheará
  user.passwordChangedAt = Date.now()
  await user.save()

  logger.info(`🔐 Contraseña actualizada correctamente para usuario ${user.email}`)
  return sendResponse(res, 200, true, 'Contraseña actualizada correctamente')
})

// 🛠️ Actualizar usuario (Perfil propio)
export const updateUser = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id || req.user?._id
  validateMongoDbIdMiddleware(userId)
  
  // Limpieza de campos sensibles/restringidos
  const updateData = { ...req.body }
  delete updateData.role
  delete updateData.isBlocked
  delete updateData.password
  delete updateData.refreshToken
  delete updateData.passwordResetToken
  
  const updated = await User.findByIdAndUpdate(userId, updateData, { new: true })
  
  if (!updated) {
    return sendResponse(res, 404, false, 'Usuario no encontrado')
  }

  logger.info(`✏️ Usuario actualizado: ${updated.email}`)
  return sendResponse(res, 200, true, 'Usuario actualizado', updated)
})


// ✅ Listar todos los usuarios (solo para admin)
export const getAllUsers = expressAsyncHandler(async (req, res) => {
  const users = await User.find().select('-password -refreshToken -passwordResetToken -__v')

  logger.info(`👥 Admin ${req.user.email} obtuvo ${users.length} usuarios`)
  res.status(200).json({ success: true, data: users })
})


// 🧾 Obtener usuario por ID
export const getUserById = expressAsyncHandler(async (req, res) => {
  const { id } = req.params
  validateMongoDbIdMiddleware(id)

  const user = await User.findById(id).select('-password')
  if (!user) {
    logger.warn(`⚠️ Usuario no encontrado: ID ${id}`)
    return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
  }

  logger.info(`👤 Usuario obtenido: ${user.email}`)
  res.status(200).json({ success: true, data: user })
})

// 🗑️ Eliminar usuario
export const deleteUser = expressAsyncHandler(async (req, res) => {
  const { id } = req.params
  validateMongoDbIdMiddleware(id)

  const user = await User.findByIdAndDelete(id)
  if (!user) {
    logger.warn(`⚠️ Usuario a eliminar no encontrado: ID ${id}`)
    return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
  }
  logger.info(`🗑️ Usuario eliminado: ${user.email}`)
  res.status(200).json({ success: true, message: 'Usuario eliminado correctamente' })
})

// 🚫 Bloquear usuario
export const blockUser = expressAsyncHandler(async (req, res) => {
  const { id } = req.params
  validateMongoDbIdMiddleware(id)

  const user = await User.findByIdAndUpdate(id, { isBlocked: true }, { new: true })
  if (!user) {
    logger.warn(`⚠️ Usuario no encontrado al intentar bloquear: ID ${id}`)
    return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
  }
  logger.info(`🔒 Usuario bloqueado: ${user.email}`)
  res.status(200).json({ success: true, message: 'Usuario bloqueado correctamente' })
})

// ✅ Desbloquear usuario
export const unblockUser = expressAsyncHandler(async (req, res) => {
  const { id } = req.params
  validateMongoDbIdMiddleware(id)

  const user = await User.findByIdAndUpdate(id, { isBlocked: false }, { new: true })
  if (!user) {
    logger.warn(`⚠️ Usuario no encontrado al intentar desbloquear: ID ${id}`)
    return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
  }
  logger.info(`🔓 Usuario desbloqueado: ${user.email}`)
  res.status(200).json({ success: true, message: 'Usuario desbloqueado correctamente' })
})


export const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 5,
  message: {
    success: false,
    message: 'Demasiadas solicitudes. Por favor, intenta de nuevo en 15 minutos.',
  },
})

export const forgotPassword = expressAsyncHandler(async (req, res) => {
  const { email } = req.body
  
  if (!email) {
    return sendResponse(res, 200, true, 'Si el correo existe, un enlace de recuperación será enviado.')
  }

  const user = await User.findOne({ email })

  if (!user) {
    logger.warn(`Intento de recuperación de contraseña para email no registrado: ${email}`)
    return sendResponse(res, 200, true, 'Si el correo existe, un enlace de recuperación será enviado.')
  }

  const resetToken = crypto.randomBytes(32).toString('hex')
  const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex')

  user.passwordResetToken = hashedToken
  user.passwordResetExpires = Date.now() + 60 * 60 * 1000
  await user.save({ validateBeforeSave: false })

  const resetUrl = `${req.protocol}://${req.get('host')}/reset-password/${resetToken}`

  const html = `
    <h4>Hola ${user.firstname || user.email},</h4>
    <p>Recibimos una solicitud para restablecer tu contraseña. Si no fuiste tú, ignora este correo.</p>
    <p>Haz clic en el siguiente enlace para restablecer tu contraseña:</p>
    <a href="${resetUrl}" target="_blank" style="padding: 10px 20px background-color: #007bff color: #fff text-decoration: none border-radius: 5px">
      Restablecer Contraseña
    </a>
    <p>Este enlace expirará en 1 hora.</p>
  `

  try {
    await sendEmail({
      to: user.email,
      subject: 'Restablece tu contraseña',
      html,
      text: `Haz clic en el siguiente enlace para restablecer tu contraseña: ${resetUrl}`,
    })

    logger.info(`📧 Correo de recuperación enviado a ${user.email}`)
    return sendResponse(res, 200, true, 'Si el correo existe, un enlace de recuperación será enviado.')
  } catch (error) {
  // Si falla el envío, limpiar los tokens en la DB
    await User.findByIdAndUpdate(user.id, {
      passwordResetToken: undefined,
      passwordResetExpires: undefined,
    }, { validateBeforeSave: false })

    logger.error(`Error enviando correo a ${user.email}: ${error.message}`)
    return sendResponse(res, 500, false, 'Hubo un problema al enviar el correo, por favor intenta de nuevo.')
  }
})

// ✅ Restablecer contraseña
export const resetPassword = expressAsyncHandler(async (req, res) => {
  const { token } = req.params
  const { password } = req.body

  if (!token || !password) {
    return res.status(400).json({ success: false, message: 'Token y nueva contraseña son obligatorios' })
  }

  // Pendiente: Validación de fuerza de contraseña usando librerías (e.g., validator)
  /* if (!validator.isStrongPassword(password, ...)) { ... } */
  if (password.length < 8) {
    return sendResponse(res, 400, false, 'La contraseña debe tener al menos 8 caracteres.')
  }

  // 🔐 Hashear token
  const hashedToken = crypto.createHash('sha256').update(token).digest('hex')

  // 🔎 Buscar usuario con token válido
  const user = await User.findOne({
    passwordResetToken: hashedToken,
    passwordResetExpires: { $gt: Date.now() },
  })

  if (!user) {
    return res.status(400).json({
      success: false,
      message: 'Token inválido o expirado. Solicita uno nuevo.',
    })
  }

  // ✅ Cambiar contraseña y limpiar datos de recuperación
  user.password = password
  user.passwordChangedAt = Date.now()
  user.passwordResetToken = undefined
  user.passwordResetExpires = undefined

  await user.save()

  logger.info(`🔑 Contraseña restablecida para: ${user.email}`)
  res.status(200).json({
    success: true,
    message: 'Contraseña restablecida correctamente. Ya puedes iniciar sesión.',
  })
})

// 📌 Obtener wishlist
export const getWishlist = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id || req.user?._id
  validateMongoDbIdMiddleware(userId)

  const user = await User.findById(userId).populate('wishlist')
  if (!user) {
    return sendResponse(res, 404, false, 'Usuario no encontrado')
  }

  logger.info(`📋 Wishlist obtenida para: ${user.email}`)
  // Devolver solo la lista para ser más RESTful
  return sendResponse(res, 200, true, 'Wishlist obtenida', user.wishlist) 
})
 
// ✅ Toggle de la lista de deseos
export const toggleWishlist = expressAsyncHandler(async (req, res) => {
  const { productId } = req.params
  const userId = req.user.id // ✅ usar id, no _id

  if (!mongoose.Types.ObjectId.isValid(productId)) {
    return res.status(400).json({ success: false, message: 'ID de producto inválido' })
  }

  try {
    const user = await User.findById(userId)
    if (!user) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' })
    }

    const alreadyAdded = user.wishlist.includes(productId)
    let updatedUser
    let message

    if (alreadyAdded) {
      updatedUser = await User.findByIdAndUpdate(
        userId,
        { $pull: { wishlist: productId } },
        { new: true },
      ).populate('wishlist')
      message = 'Producto eliminado de la lista de deseos.'
    } else {
      updatedUser = await User.findByIdAndUpdate(
        userId,
        { $addToSet: { wishlist: productId } }, // $addToSet previene duplicados
        { new: true },
      ).populate('wishlist')
      message = 'Producto añadido a la lista de deseos.'
    }

    return sendResponse(res, 200, true, message, updatedUser.wishlist)
  } catch (error) {
    logger.error(`❌ Error en toggleWishlist: ${error.message}`)
    return res.status(500).json({ success: false, message: 'Error interno del servidor.' })
  }
})

// --- Dirección ---

// Validación de la dirección (usada como middleware)
export const validateAddress = [
  body('address')
    .trim()
    .notEmpty()
    .withMessage('La dirección es obligatoria')
    .isString()
    .withMessage('La dirección debe ser un texto válido'),
]

// 📌 Guardar dirección
export const saveAddress = [
  ...validateAddress, // Aplicar validación

  expressAsyncHandler(async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map(err => err.msg)
      return sendResponse(res, 400, false, 'Error de validación', errorMessages)
    }

    const userId = req.user?.id || req.user?._id
    validateMongoDbIdMiddleware(userId)

    const { address } = req.body
    
    // Asumiendo que 'address' es un campo simple, no un subdocumento
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { address },
      { new: true, runValidators: true, select: '-password -refreshToken' },
    )

    if (!updatedUser) {
      return sendResponse(res, 404, false, 'Usuario no encontrado')
    }

    logger.info(`🏠 Dirección actualizada para: ${updatedUser.email}`)
    return sendResponse(res, 200, true, 'Dirección actualizada correctamente', updatedUser)
  }),
]

const isValidId = id => mongoose.Types.ObjectId.isValid(id)

// ======================================================
// 🛒 Agregar / actualizar producto en carrito
// ======================================================
export const userCart = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  if (!isValidId(userId)) {
    return res.status(401).json({ success: false, message: 'No autorizado' })
  }

  const { productId, quantity, colorId, size, gender } = req.body || {}

  // --------------------
  // Validaciones
  // --------------------
  if (!isValidId(productId)) {
    return res.status(400).json({ success: false, message: 'productId inválido' })
  }

  if (!Number.isInteger(quantity) || quantity < 1) {
    return res
      .status(400)
      .json({ success: false, message: 'quantity debe ser entero positivo' })
  }

  // --------------------
  // Producto real
  // --------------------
  const product = await Product.findById(productId)
    .select('price title images currency stock isDeleted')
    .lean()

  if (!product || product.isDeleted) {
    return res
      .status(404)
      .json({ success: false, message: 'Producto no disponible' })
  }

  // --------------------
  // Carrito
  // --------------------
  let cart = await Cart.findOne({ userId })
  if (!cart) {
    cart = await Cart.create({ userId })
  }

  // --------------------
  // Mutación controlada (modelo manda)
  // --------------------
  const { action } = await cart.addOrUpdateProduct({
    product,
    quantity,
    colorId: colorId || null,
    size: size || null,
    gender: gender || null,
  })

  logger.info(`🛒 Producto ${action} en carrito user=${userId}`)

  return res.status(200).json({
    success: true,
    action, // added | updated
    message:
      action === 'added'
        ? 'Producto agregado al carrito'
        : 'Cantidad actualizada en el carrito',
    data: cart,
  })
})


// ======================================================
// 🛒 Obtener carrito del usuario
// ======================================================
export const getUserCart = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  if (!isValidId(userId)) {
    return res.status(401).json({ success: false, message: 'No autorizado' })
  }

  const cart = await Cart.findOne({ userId })
    .populate('products.productId', 'title price images stock')
    .populate('products.colorId', 'title')
    .populate('appliedCoupon', 'code discount')
    .lean()

  if (!cart) {
    return res.status(200).json({
      products: [],
      cartTotal: 0,
      totalAfterDiscount: 0,
      appliedCoupon: null,
    })
  }

  return res.status(200).json({
    products: cart.products,
    cartTotal: cart.cartTotal,
    totalAfterDiscount: cart.totalAfterDiscount,
    appliedCoupon: cart.appliedCoupon,
  })
})


// ======================================================
// 🧹 Vaciar carrito
// ======================================================
export const emptyCart = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  if (!isValidId(userId)) {
    return res.status(401).json({ success: false, message: 'No autorizado' })
  }

  await Cart.deleteOne({ userId })

  logger.info(`🧹 Carrito vaciado user=${userId}`)

  return res.status(200).json({
    success: true,
    message: 'Carrito vacío correctamente',
  })
})


// ======================================================
// ❌ Eliminar item específico del carrito
// ======================================================
export const removeFromCart = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  const { productId } = req.params
  console.log(productId)

  if (!isValidId(userId) || !isValidId(productId)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const cart = await Cart.findOne({ userId })
  if (!cart) {
    return res
      .status(404)
      .json({ success: false, message: 'Carrito no encontrado' })
  }

  await cart.removeProduct(productId)

  logger.info(`🗑 Item ${productId} eliminado del carrito user=${userId}`)

  return res.status(200).json({
    success: true,
    message: 'Producto eliminado del carrito',
    data: cart,
  })
})


export const applyCoupon = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  if (!userId) return res.status(401).json({ success: false, message: 'No autorizado' })

  const { coupon } = req.body
  const validCoupon = await Coupon.findOne({ coupon, isActive: true })
  console.log('Cupón encontrado:', validCoupon)
  if (!validCoupon) {
    return res.status(400).json({ success: false, message: 'Cupón inválido' })
  }

  const cart = await Cart.findOne({ userId })
    .populate('products.productId', 'title price slug')
    .populate('appliedCoupon', 'code discount')
  if (!cart) {
    return res.status(404).json({ success: false, message: 'Carrito no encontrado' })
  }

  const totalAfterDiscount = cart.cartTotal - (cart.cartTotal * validCoupon.discount) / 100
  const discountAmount = (cart.cartTotal * validCoupon.discount) / 100

  // Opcional: guardar el cupón aplicado
  cart.appliedCoupon = validCoupon._id
  await cart.save()

  res.status(200).json({ success: true,discount:discountAmount, totalAfterDiscount, appliedCoupon: validCoupon.code })
})
