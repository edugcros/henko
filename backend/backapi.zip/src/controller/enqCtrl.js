import Enquiry from '../models/enqModel.js'
import asyncHandler from 'express-async-handler'
import mongoose from 'mongoose'
import validator from 'validator'
import logger from '../../config/logger.js'

// Crear nueva consulta
export const createEnquiry = asyncHandler(async (req, res) => {
  const { name, email, mobile, comment } = req.body

  if (!name || !email || !mobile || !comment) {
    return res.status(400).json({ success: false, message: 'Todos los campos son obligatorios' })
  }
  if (!validator.isEmail(email)) {
    return res.status(400).json({ success: false, message: 'Email inválido' })
  }
  if (!validator.isMobilePhone(mobile + '', 'any')) {
    return res.status(400).json({ success: false, message: 'Número de teléfono inválido' })
  }
  if (comment.length > 1000) {
    return res.status(400).json({ success: false, message: 'El comentario es demasiado largo (máx 1000 caracteres)' })
  }

  const newEnquiry = await Enquiry.create({ name: name.trim(), email: email.trim(), mobile, comment: comment.trim() })
  logger.info(`Nueva consulta creada (ID: ${newEnquiry._id}) por ${email}`)
  
  res.status(201).json({ success: true, data: newEnquiry })
})

// Obtener todas las consultas (admin) con paginación
export const getAllEnquiries = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page) || 1
  const limit = parseInt(req.query.limit) || 20
  const skip = (page - 1) * limit

  const [enquiries, total] = await Promise.all([
    Enquiry.find().skip(skip).limit(limit).sort({ createdAt: -1 }),
    Enquiry.countDocuments(),
  ])

  res.status(200).json({
    success: true,
    data: enquiries,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit),
    },
  })
})

// Obtener una consulta
export const getEnquiryById = asyncHandler(async (req, res) => {
  const { id } = req.params
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const enquiry = await Enquiry.findById(id)
  if (!enquiry) {
    return res.status(404).json({ success: false, message: 'Consulta no encontrada' })
  }

  res.status(200).json({ success: true, data: enquiry })
})

// Actualizar estado
export const updateEnquiryStatus = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { status } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const allowedStatuses = Enquiry.schema.path('status').enumValues
  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ success: false, message: 'Estado inválido' })
  }

  const updatedEnquiry = await Enquiry.findByIdAndUpdate(id, { status }, { new: true, runValidators: true })
  if (!updatedEnquiry) {
    return res.status(404).json({ success: false, message: 'Consulta no encontrada' })
  }

  logger.info(`Consulta (ID: ${id}) actualizada a estado: ${status}`)
  res.status(200).json({ success: true, data: updatedEnquiry })
})

// Eliminar consulta
export const deleteEnquiry = asyncHandler(async (req, res) => {
  const { id } = req.params
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const deletedEnquiry = await Enquiry.findByIdAndDelete(id)
  if (!deletedEnquiry) {
    return res.status(404).json({ success: false, message: 'Consulta no encontrada' })
  }

  logger.warn(`Consulta eliminada (ID: ${deletedEnquiry._id})`)
  res.status(200).json({ success: true, message: 'Consulta eliminada correctamente' })
})
