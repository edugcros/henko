// 📁 src/controller/themeController.js
import asyncHandler from 'express-async-handler'
import ThemeConfig from '../models/themeConfigModels.js'
import logger from '../../config/logger.js'

/**
 * Crear tema draft
 * POST /api/theme
 * Acceso: Admin/Moderator
 */
export const createThemeDraft = asyncHandler(async (req, res) => {
  const user = req.user
  if (!req.body) return res.status(400).json({ success: false, message: 'Payload requerido' })

  const tenantId = user?.tenantId
  if (!tenantId) return res.status(403).json({ success: false, message: 'Tenant no definido en token' })

  try {
    const theme = await ThemeConfig.create({
      ...req.body,
      tenantId,
      status: 'draft',
      metadata: {
        createdBy: user.id,
        createdAt: new Date(),
        updatedBy: user.id,
        updatedAt: new Date(),
      },
    })
    res.status(201).json({ success: true, data: theme })
  } catch (err) {
    logger.error('[createThemeDraft] Error creando tema:', err)
    res.status(500).json({ success: false, message: err.message || 'Error interno del servidor' })
  }
})

/**
 * Actualizar tema
 * PATCH /api/theme/:id
 * Acceso: Admin/Moderator
 */
export const updateTheme = asyncHandler(async (req, res) => {
  const { id } = req.params
  const user = req.user

  if (!id) return res.status(400).json({ success: false, message: 'ID requerido' })

  try {
    const theme = await ThemeConfig.findById(id)
    if (!theme) return res.status(404).json({ success: false, message: 'Tema no encontrado' })

    if (theme.tenantId !== user.tenantId) {
      return res.status(403).json({ success: false, message: 'Forbidden: No pertenece a tu tenant' })
    }

    Object.assign(theme, req.body)
    theme.metadata.updatedBy = user.id
    theme.metadata.updatedAt = new Date()

    await theme.save()
    res.status(200).json({ success: true, data: theme })
  } catch (err) {
    logger.error('[updateTheme] Error actualizando tema:', err)
    res.status(500).json({ success: false, message: err.message || 'Error interno del servidor' })
  }
})

/**
 * Obtener tema publicado del tenant
 * GET /api/theme/published
 * Acceso: Público
 */
export const getPublishedTheme = asyncHandler(async (req, res) => {
  try {
    const tenantId = req.user?.tenantId || req.query?.tenantId
    if (!tenantId) return res.status(400).json({ success: false, message: 'TenantId requerido' })

    const theme = await ThemeConfig.findOne({ tenantId, status: 'published' }).lean()
    if (!theme) return res.status(404).json({ success: false, message: 'No hay tema publicado' })

    res.status(200).json({ success: true, data: theme })
  } catch (err) {
    logger.error('[getPublishedTheme] Error obteniendo tema publicado:', err)
    res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})

/**
 * Obtener todos los temas de un tenant
 * GET /api/theme
 * Acceso: Admin/Moderator
 */
export const getThemes = asyncHandler(async (req, res) => {
  const tenantId = req.user?.tenantId
  if (!tenantId) return res.status(403).json({ success: false, message: 'Tenant no definido en token' })

  try {
    const themes = await ThemeConfig.find({ tenantId }).lean()
    res.status(200).json({ success: true, data: themes })
  } catch (err) {
    logger.error('[getThemes] Error obteniendo temas:', err)
    res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})

/**
 * Publicar tema
 * POST /api/theme/:id/publish
 * Acceso: Admin
 */
export const publishTheme = asyncHandler(async (req, res) => {
  const { id } = req.params
  const user = req.user

  if (!id) return res.status(400).json({ success: false, message: 'ID requerido' })

  try {
    const theme = await ThemeConfig.findById(id)
    if (!theme) return res.status(404).json({ success: false, message: 'Tema no encontrado' })

    if (theme.tenantId !== user.tenantId) {
      return res.status(403).json({ success: false, message: 'Forbidden: No pertenece a tu tenant' })
    }

    theme.status = 'published'
    theme.metadata.updatedBy = user.id
    theme.metadata.updatedAt = new Date()

    await theme.save()
    res.status(200).json({ success: true, data: theme })
  } catch (err) {
    logger.error('[publishTheme] Error publicando tema:', err)
    res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})

/**
 * Obtener tema por ID
 * GET /api/theme/:id
 * Acceso: Admin/Moderator
 */
export const getThemeById = asyncHandler(async (req, res) => {
  const { id } = req.user
  console.log('Getting theme by ID:', id)
  const user = req.user
  console.log('Getting theme by ID:', user)

  if (!id) return res.status(400).json({ success: false, message: 'ID requerido' })

  try {
    const theme = await ThemeConfig.findById(id).lean()
    if (!theme) return res.status(404).json({ success: false, message: 'Tema no encontrado' })

    if (theme.tenantId !== user.tenantId) {
      return res.status(403).json({ success: false, message: 'Forbidden: No pertenece a tu tenant' })
    }

    res.status(200).json({ success: true, data: theme })
  } catch (err) {
    logger.error('[getThemeById] Error obteniendo tema por ID:', err)
    res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})
