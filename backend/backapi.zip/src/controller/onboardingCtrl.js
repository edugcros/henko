import asyncHandler from 'express-async-handler'
import { respondSuccess, respondError } from '../utils/response.js'
import Onboarding from '../models/onboardingModel.js'
import FLRU from 'flru'

const cache = new FLRU(100)

const generateSmartSuggestion = ({ productType, brand, style }) => {
  const keywords = style.toLowerCase().split(',').map(s => s.trim())
  const keyword = keywords[0] || 'moderno'
  const name = `${brand || 'Nova'} ${keyword.charAt(0).toUpperCase() + keyword.slice(1)}`
  const categories = ['Novedades', 'Populares', productType.charAt(0).toUpperCase() + productType.slice(1)]
  return { name, categories, logo: null }
}

export const onboardingAIHandler = asyncHandler(async (req, res) => {
  const { productType, brand, style } = req.body
  if (!productType || !style) return respondError(res, 400, 'Faltan datos esenciales.')

  const key = `${productType}-${brand}-${style}`.toLowerCase()
  if (cache.has(key)) return respondSuccess(res, 200, 'Desde cache', cache.get(key))

  try {
    const result = generateSmartSuggestion({ productType, brand, style })
    cache.set(key, result)
    respondSuccess(res, 200, 'Generado con IA local', result)
  } catch (err) {
    console.error('[IA fallback]', err)
    respondSuccess(res, 200, 'Generado por fallback', {
      name: brand || 'Tienda Creativa',
      categories: ['Cat1', 'Cat2', 'Cat3'],
      logo: null,
    })
  }
})

export const saveOnboardingResult = asyncHandler(async (req, res) => {
  const { name, categories, logo } = req.body
  const userId = req.user?._id
  if (!name || !categories?.length || !userId) return respondError(res, 400, 'Datos incompletos')

  const newShop = await Onboarding.create({
    user: userId,
    name,
    categories,
    logo: logo || null,
    status: 'draft',
    appliedToStore: false,
  })

  respondSuccess(res, 201, 'Guardado', newShop)
})

export const getMyOnboardingResults = asyncHandler(async (req, res) => {
  const userId = req.user?._id
  if (!userId) return respondError(res, 401, 'No autorizado')
  const results = await Onboarding.find({ user: userId }).sort({ createdAt: -1 })
  respondSuccess(res, 200, 'Encontrado', results)
})

export const deleteOnboardingResult = asyncHandler(async (req, res) => {
  const entry = await Onboarding.findOne({ _id: req.params.id, user: req.user._id })
  if (!entry) return respondError(res, 404, 'Tienda no encontrada')
  await entry.remove()
  respondSuccess(res, 200, 'Eliminado')
})

export const updateOnboardingResult = asyncHandler(async (req, res) => {
  const { name, categories, logo, status, appliedToStore } = req.body
  const entry = await Onboarding.findOne({ _id: req.params.id, user: req.user._id })
  if (!entry) return respondError(res, 404, 'No encontrada')

  if (name) entry.name = name
  if (categories) entry.categories = categories
  if (logo !== undefined) entry.logo = logo
  if (status) entry.status = status
  if (appliedToStore !== undefined) entry.appliedToStore = appliedToStore

  await entry.save()
  respondSuccess(res, 200, 'Actualizada', entry)
})
