import Product from '../models/productModel.js'
import expressAsyncHandler from 'express-async-handler'
import { validationResult } from 'express-validator'
import fs from 'fs/promises'
import path from 'path'
import { fileURLToPath } from 'url'
import rateLimit from 'express-rate-limit'
import logger from '../../config/logger.js'
import mongoose from 'mongoose'
import { cloudinaryUploadImg } from '../utils/cloudinary.js'
import { generateUniqueSlug } from '../utils/slugService.js'

// Helper para asegurar la existencia del directorio de subidas locales
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const rootDir = path.resolve(__dirname, '../../')

const ensureDir = async dir => {
  try {
    await fs.mkdir(dir, { recursive: true })
  } catch (_) {_}
}

const publicBaseUrl = () => process.env.PUBLIC_URL || ''

// Middleware para validar el ID de MongoDB
const validateMongoDbId = id => {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new Error('ID de MongoDB inválido')
  }
}

// Lógica de validación
export const createProduct = [
  async (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }

    const user = req.user
    console.log('Authenticated user in createProduct:', user)
    if (!user) return res.status(401).json({ success: false, message: 'No autenticado' })
    const tenantId = user.tenantId 
    console.log('Tenant ID in createProduct:', tenantId)

    const {
      title,
      marca,
      description,
      categoria,
      subcategoria,
      atributos,
      tags,
      price,
      stock,
      condicion,
      brand,
      color,
      iaGenerated,
      iaSource,
      validado,
      visual_info,
      llm_metadata,
    } = req.body

    const slug = await generateUniqueSlug({ title, tenantId })

    const exists = await Product.findOne({ slug })
    if (exists) {
      logger.warn(`⚠️ Ya existe un producto con el slug: ${slug} para el tenant: ${tenantId}`)
      return res.status(409).json({ success: false, message: 'Ya existe un producto con este título' })
    }

    const embeddingArray = Array.isArray(visual_info?.embedding) 
      ? visual_info.embedding 
      : []

    const productData = {
      tenantId,
      title,
      marca,
      slug,
      description,
      categoria,
      subcategoria,
      atributos,
      tags,
      price,
      stock,
      condicion,
      brand,
      color,
      iaGenerated: !!iaGenerated,
      iaSource: iaSource || null,
      validado: !!validado,
      visual_info: visual_info || {},
      llm_metadata: llm_metadata || {},
      // USAMOS LA VARIABLE LIMPIA
      embeddings: embeddingArray,
    }

    const newProduct = await Product.create(productData)
    logger.info(`✅ Producto creado para tenant ${tenantId}: ${title}`)
    res.status(201).json({ success: true, data: newProduct })
  },
]

// Obtener un producto
export const getaProduct = expressAsyncHandler(async (req, res) => {
  const { id } = req.params
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID de producto inválido' })
  }
  try {
    const product = await Product.findById(id).lean()
    if (!product) {
      return res.status(404).json({ success: false, message: 'Producto no encontrado' })
    }
    return res.status(200).json({ success: true, data: product })
  } catch (error) {
    logger.error('Error al obtener producto:', error)
    return res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})

export const getAllProduct = expressAsyncHandler(async (req, res) => {
  try {
    const {
      all = true,        // ?all=true para traer todo
      page = 1,
      categoria,
      marca,
      limit,
      subcategoria,
      q,
      minPrice,
      maxPrice,
      inStock,
      sort = 'created-desc',
    } = req.query

    const pageNum = Math.max(1, parseInt(page, 10) || 1)
    const pageSize = limit === 'all' ? 0 : (parseInt(limit,10) || 12)

    const query = {}

    // Filtros opcionales
    if (categoria) query.categoria = categoria
    if (marca) query.marca = marca
    if (subcategoria) query.subcategoria = subcategoria
    if (inStock === 'true') query.stock = { $gt: 0 }
    if (minPrice != null || maxPrice != null) {
      query.price = {}
      if (minPrice != null) query.price.$gte = Number(minPrice)
      if (maxPrice != null) query.price.$lte = Number(maxPrice)
    }

    // Busqueda por texto
    if (q && typeof q === 'string') {
      const regex = new RegExp(q.trim(), 'i')
      query.$or = [
        { title: regex },
        { description: regex },
        { 'atributos.marca': { $regex: regex, $options: 'i' } },
        { tags: { $in: [regex] } },
      ]
    }

    const sortMap = {
      'price-asc': { price: 1 },
      'price-desc': { price: -1 },
      'created-asc': { createdAt: 1 },
      'created-desc': { createdAt: -1 },
      'title-asc': { title: 1 },
      'title-desc': { title: -1 },
      'rating-desc': { totalrating: -1 },
    }
    const sortObj = sortMap[sort] || { createdAt: -1 }

    const projection = {
      title: 1,
      slug: 1,
      description: 1,
      categoria: 1,
      subcategoria: 1,
      marca: 1,
      brand: 1,
      color: 1,
      atributos: 1,
      tags: 1,
      price: 1,
      stock: 1,
      condicion: 1,
      iaGenerated: 1,
      iaSource: 1,
      validado: 1,
      visual_info: 1,
      llm_metadata: 1,
      embeddings: 1,
      images: 1,
      ratings: 1,
      totalrating: 1,
      tenantId: 1,
      createdAt: 1,
      updatedAt: 1,
    }


    // Contar total de documentos
    const total = await Product.countDocuments(query)

    if (all === 'true' || all === true) {
      // --- STREAMING PARA TODOS LOS PRODUCTOS ---
      res.setHeader('Content-Type', 'application/json')
      res.write('{"success":true,"total":' + total + ',"data":[')

      let first = true
      const cursor = Product.find(query, projection).sort(sortObj).cursor()
      cursor.on('data', doc => {
        if (!first) res.write(',')
        res.write(JSON.stringify(doc))
        first = false
      })
      cursor.on('end', () => res.end(']}'))
      cursor.on('error', err => {
        logger.error('Error en stream de productos', err)
        if (!res.headersSent) res.status(500).json({ success: false, message: 'Error enviando productos' })
      })
      logger.info(`📦 Streaming de todos los productos enviado, total=${total}`)
    } else {
      // --- PAGINACION NORMAL ---
      const totalPages = Math.ceil(total / pageSize) || 1
      const skip = (pageNum - 1) * pageSize

      const products = await Product.find(query, projection)
        .sort(sortObj)
        .skip(skip)
        .limit(pageSize)
        .lean()

      res.status(200).json({
        success: true,
        total,
        page: pageNum,
        pageSize,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrev: pageNum > 1,
        data: products,
      })

      logger.info(`📦 Productos listados (paginación) total=${total} page=${pageNum}`)
    }
  } catch (err) {
    logger.error('Error en getAllProduct', { err })
    res.status(500).json({ success: false, message: 'Error interno del servidor' })
  }
})

// Actualizar un producto
export const updateProduct = expressAsyncHandler(async (req, res) => {
  const { productId } = req.params
  validateMongoDbId(productId)

  const updates = req.body
  if (updates.title) {
    updates.slug = generateUniqueSlug(updates.title.trim(), { lower: true })
  }
  const updatedProduct = await Product.findByIdAndUpdate(productId, updates, {
    new: true,
    runValidators: true,
  })
  if (!updatedProduct) {
    logger.warn(`❌ Falló la actualización. Producto no encontrado: ID ${productId}`)
    return res.status(404).json({ success: false, message: 'Producto no encontrado' })
  }
  logger.info(`✅ Producto actualizado: ID ${productId}`)
  res.status(200).json({ success: true, data: updatedProduct })
})

// Eliminar un producto
export const deleteProduct = expressAsyncHandler(async (req, res) => {
  const { productId } = req.params
  validateMongoDbId(productId)
  const deletedProduct = await Product.findByIdAndDelete(productId)
  if (!deletedProduct) {
    logger.warn(`❌ Falló la eliminación. Producto no encontrado: ID ${productId}`)
    return res.status(404).json({ success: false, message: 'Producto no encontrado' })
  }
  logger.info(`🗑️ Producto eliminado: ID ${productId}`)
  res.status(200).json({ success: true, message: 'Producto eliminado correctamente' })
})

// Subir una imagen de producto
// Subir una imagen de producto (versión optimizada para producción)
export const uploadProductImage = async (req, res) => {
  try {
    const { productId } = req.params
    const alt = (req.body?.alt || '').toString().slice(0, 120)

    // ================================
    // VALIDACIONES CRÍTICAS
    // ================================
    if (!req.file || !req.file.processedBuffer) {
      return res.status(400).json({
        success: false,
        message: 'Imagen no procesada o inválida',
      })
    }

    if (!productId || productId.length < 10) {
      return res.status(400).json({
        success: false,
        message: 'ID de producto inválido',
      })
    }

    const product = await Product.findById(productId)
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado',
      })
    }

    // ================================
    // DRIVER
    // ================================
    const driver = (process.env.STORAGE_DRIVER || 'cloudinary').toLowerCase()

    let url = ''
    let public_id = ''

    // ================================
    // CLOUDINARY
    // ================================
    if (driver === 'cloudinary') {
      try {
        const uploaded = await cloudinaryUploadImg(req.file.processedBuffer, productId)
        url = uploaded.url
        public_id = uploaded.public_id
      } catch (cloudErr) {
        logger.error('❌ Error subiendo a Cloudinary', {
          message: cloudErr.message,
          code: cloudErr.code,
        })

        return res.status(502).json({
          success: false,
          message: 'Error subiendo la imagen al servidor de almacenamiento',
        })
      }
    }

    // ================================
    // ALMACENAMIENTO LOCAL (fallback)
    // ================================
    else {
      try {
        const folderAbs = path.join(rootDir, 'uploads', 'products', productId)
        await ensureDir(folderAbs)

        const fileName = req.file.safeName
        const absPath = path.join(folderAbs, fileName)

        await fs.writeFile(absPath, req.file.processedBuffer)

        // Ruta pública
        public_id = path.posix.join('products', productId, fileName)
        url = `${publicBaseUrl()}/uploads/${public_id}`.replace(/(?<!:)\/{2,}/g, '/')
      } catch (localErr) {
        logger.error('❌ Error guardando archivo local', { message: localErr.message })
        return res.status(500).json({
          success: false,
          message: 'Error guardando imagen localmente',
        })
      }
    }

    // ================================
    // PUSH + CONTROL DE IMAGEN PRINCIPAL
    // ================================
    const isFirstImage = product.images.length === 0

    product.images.push({
      url,
      public_id,
      alt,
      isMain: isFirstImage,
    })

    // Mantener **solo UNA** imagen como principal
    if (!isFirstImage) {
      product.images = product.images.map((img, idx) => ({
        ...img.toObject(),
        isMain: idx === 0,
      }))
    }

    await product.save()

    logger.info(`📸 Imagen subida para producto ${productId} (${driver}): ${public_id}`)

    return res.status(201).json({
      success: true,
      data: product.images,
    })
  } catch (err) {
    logger.error('❌ Error subiendo imagen de producto', {
      message: err.message,
      stack: err.stack,
    })

    return res.status(500).json({
      success: false,
      message: 'Error interno al subir imagen',
    })
  }
}

// Eliminar una imagen de producto
export const deleteProductImage = async (req, res) => {
  try {
    const { productId, public_id } = req.params
    validateMongoDbId(productId)
    const driver = (process.env.STORAGE_DRIVER || 'cloudinary').toLowerCase()

    const product = await Product.findById(productId)
    if (!product) return res.status(404).json({ success: false, message: 'Producto no encontrado' })

    const idx = product.images.findIndex(img => String(img.public_id) === String(public_id))
    if (idx === -1) return res.status(404).json({ success: false, message: 'Imagen no encontrada en el producto' })

    if (driver === 'cloudinary') {
      // Usar un método de eliminación de Cloudinary, si existe
      // await cloudinary.uploader.destroy(public_id, { resource_type: 'image' })
    } else {
      const abs = path.join(rootDir, 'uploads', public_id)
      try { await fs.unlink(abs) } catch (_) {_}
    }

    const wasMain = !!product.images[idx]?.isMain
    product.images.splice(idx, 1)
    if (wasMain && product.images.length) product.images[0].isMain = true
    await product.save()

    logger.info(`🗑️ Imagen eliminada ${public_id} del producto ${productId} (${driver})`)
    return res.status(200).json({ success: true, data: product.images })
  } catch (err) {
    logger.error('Error eliminando imagen de producto', { err })
    return res.status(500).json({ success: false, message: 'Error eliminando imagen' })
  }
}

// Calificar un producto
export const rating = expressAsyncHandler(async (req, res) => {
  const { productId } = req.params
  const { star, comment } = req.body
  const { _id } = req.user

  if (!star || star < 1 || star > 5) {
    logger.warn('❌ Calificación inválida. Debe estar entre 1 y 5 estrellas')
    return res.status(400).json({
      success: false,
      message: 'La calificación debe estar entre 1 y 5 estrellas',
    })
  }

  const product = await Product.findById(productId)
  if (!product) {
    logger.warn(`❌ Producto no encontrado para calificación: ID ${productId}`)
    return res.status(404).json({
      success: false,
      message: 'Producto no encontrado',
    })
  }

  const existingRating = product.ratings.find(
    r => r.postedBy.toString() === _id.toString(),
  )

  if (existingRating) {
    existingRating.star = star
    existingRating.comment = comment
  } else {
    product.ratings.push({ star, comment, postedby: _id })
  }

  const totalStars = product.ratings.reduce((acc, r) => acc + r.star, 0)
  const avgRating = totalStars / product.ratings.length
  product.totalrating = Number(avgRating.toFixed(1))

  await product.save()

  logger.info(`⭐ Producto calificado: ID ${productId}, estrellas: ${star}, usuario: ${_id}`)
  res.status(200).json({ success: true, data: product })
})

export const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { success: false, message: 'Demasiadas solicitudes, intenta nuevamente más tarde.' },
})