import Store from '../models/storeModel.js'
import { respondSuccess, respondError } from '../utils/response.js'
import asyncHandler from 'express-async-handler'

// GET /api/store/my-stores
export const getMyStores = asyncHandler(async (req, res) => {
  const stores = await Store.find({ owner: req.user._id })
  respondSuccess(res, 200, 'Tiendas del usuario', stores)
})

// POST /api/store/
export const createStore = asyncHandler(async (req, res) => {
  const { name, description, logo } = req.body
  const exist = await Store.findOne({ owner: req.user._id })
  if (exist) return respondError(res, 400, 'Ya tienes una tienda creada')
  const store = await Store.create({
    owner: req.user._id,
    name,
    description,
    logo,
    status: 'active',
  })
  respondSuccess(res, 201, 'Tienda creada', store)
})
