import Coupon from '../models/couponModel.js'
import asyncHandler from 'express-async-handler'
import mongoose from 'mongoose'
import logger from '../../config/logger.js'

// Crear un nuevo cupón
export const createCoupon = asyncHandler(async (req, res) => {
  let { name, discount, expiry } = req.body

  if (!name || !discount || !expiry) {
    return res.status(400).json({ success: false, message: 'Todos los campos son obligatorios' })
  }

  name = name.trim().toUpperCase()

  if (discount <= 0 || discount > 100) {
    return res.status(400).json({ success: false, message: 'El descuento debe estar entre 1 y 100' })
  }

  const expiryDate = new Date(expiry)
  if (isNaN(expiryDate.getTime()) || expiryDate <= new Date()) {
    return res.status(400).json({ success: false, message: 'La fecha de expiración debe ser futura' })
  }

  const existingCoupon = await Coupon.findOne({ name })
  if (existingCoupon) {
    return res.status(409).json({ success: false, message: 'El cupón ya existe' })
  }

  const newCoupon = await Coupon.create({ name, discount, expiry: expiryDate })
  logger.info(`Cupón creado: ${name} (ID: ${newCoupon._id})`)
  res.status(201).json({ success: true, data: newCoupon })
})

// Obtener todos los cupones con paginación
export const getAllCoupons = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page) || 1
  const limit = parseInt(req.query.limit) || 20
  const skip = (page - 1) * limit

  const [coupons, total] = await Promise.all([
    Coupon.find().skip(skip).limit(limit).sort({ expiry: 1 }),
    Coupon.countDocuments(),
  ])

  res.status(200).json({
    success: true,
    data: coupons,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit),
    },
  })
})

// Obtener un cupón por ID
export const getCouponById = asyncHandler(async (req, res) => {
  const { id } = req.params
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const coupon = await Coupon.findById(id)
  if (!coupon) {
    return res.status(404).json({ success: false, message: 'Cupón no encontrado' })
  }

  res.status(200).json({ success: true, data: coupon })
})

// Actualizar un cupón
export const updateCoupon = asyncHandler(async (req, res) => {
  const { id } = req.params
  let { name, discount, expiry } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  if (name) {
    name = name.trim().toUpperCase()
    const duplicate = await Coupon.findOne({ name })
    if (duplicate && duplicate._id.toString() !== id) {
      return res.status(409).json({ success: false, message: 'Ya existe un cupón con ese nombre' })
    }
  }

  if (discount && (discount <= 0 || discount > 100)) {
    return res.status(400).json({ success: false, message: 'El descuento debe estar entre 1 y 100' })
  }

  if (expiry) {
    const expiryDate = new Date(expiry)
    if (isNaN(expiryDate.getTime()) || expiryDate <= new Date()) {
      return res.status(400).json({ success: false, message: 'La fecha de expiración debe ser futura' })
    }
    expiry = expiryDate
  }

  const updatedCoupon = await Coupon.findByIdAndUpdate(
    id,
    { name, discount, expiry },
    { new: true, runValidators: true },
  )

  if (!updatedCoupon) {
    return res.status(404).json({ success: false, message: 'Cupón no encontrado' })
  }

  logger.info(`Cupón actualizado: ${updatedCoupon.name} (ID: ${updatedCoupon._id})`)
  res.status(200).json({ success: true, data: updatedCoupon })
})

// Eliminar un cupón
export const deleteCoupon = asyncHandler(async (req, res) => {
  const { id } = req.params
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: 'ID inválido' })
  }

  const deletedCoupon = await Coupon.findByIdAndDelete(id)
  if (!deletedCoupon) {
    return res.status(404).json({ success: false, message: 'Cupón no encontrado' })
  }

  logger.warn(`Cupón eliminado: ${deletedCoupon.name} (ID: ${deletedCoupon._id})`)
  res.status(200).json({ success: true, message: 'Cupón eliminado correctamente' })
})

// Validar cupón
export const validateCoupon = asyncHandler(async (req, res) => {
  const { code } = req.body
  if (!code) {
    return res.status(400).json({ success: false, message: 'Código de cupón requerido' })
  }

  const coupon = await Coupon.findOne({ name: code.trim().toUpperCase() })
  if (!coupon || !coupon.isValid()) {
    return res.status(400).json({ success: false, message: 'Cupón inválido o expirado' })
  }

  res.status(200).json({ success: true, data: coupon })
})
