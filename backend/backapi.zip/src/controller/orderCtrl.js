// 📁 src/controller/orderCtrl.js
import mongoose from 'mongoose'
import expressAsyncHandler from 'express-async-handler'
import crypto from 'crypto'
import rateLimit from 'express-rate-limit'
import Order from '../models/orderModel.js'
import Product from '../models/productModel.js'
import Cart from '../models/cartModel.js'
import Coupon from '../models/couponModel.js'
import logger from '../../config/logger.js'

// ======================
// Constants / Helpers
// ======================
export const ORDER_STATUS = {
  NOT_PROCESSED: 'not processed',
  CASH_ON_DELIVERY: 'cash on delivery',
  PROCESSING: 'processing',
  DISPATCHED: 'dispatched',
  CANCELLED: 'cancelled',
  DELIVERED: 'delivered',
  REFUNDED: 'refunded',
}

const ALLOWED_CURRENCIES = ['USD', 'ARS', 'EUR']
const toCents = n => Math.round(Number(n) * 100)
const fromCents = n => n / 100
const isValidId = id => mongoose.Types.ObjectId.isValid(id)

// ======================
// Rate limiter
// ======================
export const orderWriteLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
})

// ======================
// Helpers
// ======================
const calculateCartLines = async cart => {
  const productIds = cart.products.map(p => p.productId)
  const dbProducts = await Product.find({ _id: { $in: productIds }, isDeleted: { $ne: true } }).select('_id price quantity title').lean()
  const pMap = new Map(dbProducts.map(p => [String(p._id), p]))

  let currency = null
  let totalCents = 0
  const lines = cart.products.map((line, idx) => {
    const dbp = pMap.get(String(line.productId))
    if (!dbp) throw new Error(`Producto no disponible (ítem ${idx + 1})`)
    const count = Number(line.quantity)
    if (!Number.isInteger(count) || count <= 0) throw new Error(`Cantidad inválida en ítem ${idx + 1}`)
    if (dbp.quantity < count) throw new Error(`Stock insuficiente para ${dbp.title}`)

    const curr = (line.currency || 'ARS').toUpperCase()
    if (!ALLOWED_CURRENCIES.includes(curr)) throw new Error(`Moneda inválida: ${curr}`)
    currency = currency || curr
    if (currency !== curr) throw new Error('Todas las líneas del carrito deben tener la misma moneda')

    const price = Number(dbp.price)
    totalCents += toCents(price) * count

    return {
      product: line.productId,
      count,
      color: line.colorId || null,
      price,
      subtotal: Math.round(price * count * 100) / 100,
      _title: dbp.title,
    }
  })

  return { lines, totalCents, currency }
}

const decrementStock = async (lines, session = null) => {
  const decremented = []
  for (const l of lines) {
    const upd = await Product.updateOne(
      { _id: l.product, isDeleted: false, quantity: { $gte: l.count } },
      { $inc: { quantity: -l.count, sold: +l.count } },
      session ? { session } : {},
    )
    if (upd.modifiedCount !== 1) throw new Error(`No se pudo actualizar stock para ${l._title}`)
    decremented.push(l)
  }
  return decremented
}

const incrementStock = async (lines, session = null) => {
  for (const l of lines) {
    await Product.updateOne(
      { _id: l.product, isDeleted: false },
      { $inc: { quantity: +l.count, sold: -l.count } },
      session ? { session } : {},
    ).catch(() => {})
  }
}

const clearCart = async (cartId, session = null) => {
  await Cart.deleteOne({ _id: cartId }, session ? { session } : {})
}

// ======================
// Controller
// ======================
export const createOrder = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  console.log('User ID:', userId)
  if (!isValidId(userId)) return res.status(401).json({ success: false, message: 'No autorizado' })

  const { COD = false, idempotencyKey } = req.body || {}

  // 1) Idempotencia
  if (idempotencyKey) {
    const existing = await Order.findOne({ 'paymentIntent.id': idempotencyKey, orderby: userId })
    if (existing) return res.status(200).json({ success: true, data: existing })
  }

  // 2) Cargar carrito
  const cart = await Cart.findOne({ userId })
  if (!cart || !Array.isArray(cart.products) || cart.products.length === 0) {
    return res.status(400).json({ success: false, message: 'El carrito está vacío' })
  }

  // 3) Calcular líneas y total
  const { lines, totalCents, currency } = await calculateCartLines(cart)

  // 4) Aplicar cupón
  let finalCents = totalCents
  let couponDoc = null
  if (cart.appliedCoupon) {
    couponDoc = await Coupon.findById(cart.appliedCoupon)
    const validity = couponDoc?.isValid?.() || { valid: false }
    if (!validity.valid) return res.status(400).json({ success: false, message: `Cupón inválido: ${validity.reason || ''}` })
    finalCents = Math.round(finalCents * (1 - couponDoc.discount / 100))
  }

  // 5) Preparar paymentIntent
  const paymentId = idempotencyKey || crypto.randomBytes(12).toString('hex')
  const paymentIntent = {
    id: paymentId,
    status: COD ? 'completed' : 'pending',
    method: COD ? 'cash on delivery' : 'credit card',
    currency: currency || 'ARS',
    amount: fromCents(finalCents),
  }

  // 6) Crear orden con transacción si se puede
  let session = null
  try {
    session = await mongoose.startSession()
    await session.withTransaction(async () => {
      await decrementStock(lines, session)
      const created = await Order.create([{
        products: lines.map(({ product, count, color, price, subtotal }) => ({ product, count, color, price, subtotal })),
        paymentIntent,
        orderStatus: COD ? ORDER_STATUS.PROCESSING : ORDER_STATUS.NOT_PROCESSED,
        orderby: userId,
      }], { session })

      await clearCart(cart._id, session)
      if (couponDoc) await Coupon.updateOne({ _id: couponDoc._id }, { $inc: { usedCount: 1 } }, { session })

      logger.info(`🧾 Orden creada (tx): ${created[0]._id} user=${userId} total=${paymentIntent.amount} ${paymentIntent.currency}`)
      res.status(201).json({ success: true, data: created[0] })
    })
    session.endSession()
    return
  } catch (txErr) {
    if (session) session.endSession()
    const isNoTxSupport = /replica set|mongos|Transaction numbers/i.test(String(txErr?.message))
    if (!isNoTxSupport) {
      logger.error(`Error crear orden (tx): ${txErr.stack || txErr.message}`)
      return res.status(400).json({ success: false, message: 'Error al crear la orden' })
    }
  }

  // 7) Fallback sin transacción
  try {
    const decremented = await decrementStock(lines)
    const order = await Order.create({
      products: lines.map(({ product, count, color, price, subtotal }) => ({ product, count, color, price, subtotal })),
      paymentIntent,
      orderStatus: COD ? ORDER_STATUS.PROCESSING : ORDER_STATUS.NOT_PROCESSED,
      orderby: userId,
      decremented,
    })
    await clearCart(cart._id)
    if (couponDoc) await Coupon.updateOne({ _id: couponDoc._id }, { $inc: { usedCount: 1 } })

    logger.info(`🧾 Orden creada (sin tx): ${order._id} user=${userId} total=${paymentIntent.amount} ${paymentIntent.currency}`)
    return res.status(201).json({ success: true, data: order })
  } catch (err) {
    await incrementStock(lines)
    logger.error(`Error crear orden (sin tx): ${err.stack || err.message}`)
    return res.status(400).json({ success: false, message: 'No se pudo crear la orden' })
  }
})


/**
 * GET /api/order
 * Órdenes del usuario autenticado (paginadas)
 */
export const getOrders = expressAsyncHandler(async (req, res) => {
  const userId = req.user?.id
  if (!isValidId(userId)) return res.status(401).json({ success: false, message: 'No autorizado' })

  const page = parseInt(req.query.page || '1', 10)
  const limit = Math.min(parseInt(req.query.limit || '20', 10), 100)
  const skip = (page - 1) * limit

  const [orders, total] = await Promise.all([
    Order.find({ orderby: userId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('products.product', 'title slug')
      .populate('products.color', 'title')
      .populate('orderby', 'firstname lastname email'),
    Order.countDocuments({ orderby: userId }),
  ])

  return res.status(200).json({
    success: true,
    data: orders,
    pagination: { total, page, pages: Math.ceil(total / limit) },
  })
})

/**
 * GET /api/order/all
 * Todas las órdenes (admin/manager) con filtros
 * Query: status, from, to, q (paymentIntent.id), page, limit
 */
export const getAllOrders = expressAsyncHandler(async (req, res) => {
  const role = req.user?.role
  if (!['admin', 'manager'].includes(role)) {
    return res.status(403).json({ success: false, message: 'Permisos insuficientes' })
  }

  const page = Math.max(parseInt(req.query.page || '1', 10), 1)
  const limit = Math.min(Math.max(parseInt(req.query.limit || '20', 10), 1), 200)
  const skip = (page - 1) * limit

  const {
    status,
    from,
    to,
    q,
    minTotal,
    maxTotal,
    currency,
    method,
    sortBy = 'createdAt',
    sortDir = 'desc',
  } = req.query

  const pipeline = []

  // -----------------------------
  // 1) MATCH inicial sobre fields simples
  // -----------------------------
  const match = {}

  if (status) match.orderStatus = status.toLowerCase()

  if (currency) match['paymentIntent.currency'] = currency.toUpperCase()
  if (method) match['paymentIntent.method'] = method.toLowerCase()

  if (from || to) {
    match.createdAt = {}
    if (from) match.createdAt.$gte = new Date(from)
    if (to) match.createdAt.$lte = new Date(to)
  }

  if (minTotal || maxTotal) {
    match['paymentIntent.amount'] = {}
    if (minTotal) match['paymentIntent.amount'].$gte = Number(minTotal)
    if (maxTotal) match['paymentIntent.amount'].$lte = Number(maxTotal)
  }

  if (Object.keys(match).length) pipeline.push({ $match: match })

  // -----------------------------
  // 2) Lookup de usuario
  // -----------------------------
  pipeline.push(
    {
      $lookup: {
        from: 'users',
        localField: 'orderby',
        foreignField: '_id',
        as: 'orderby_doc',
      },
    },
    {
      $unwind: {
        path: '$orderby_doc',
        preserveNullAndEmptyArrays: true,
      },
    },
  )

  // -----------------------------
  // 3) BÚSQUEDA GLOBAL (q)
  // -----------------------------
  if (q && q.trim() !== '') {
    const qs = q.trim()
    const regex = new RegExp(qs, 'i')

    const or = [
      { 'paymentIntent.id': regex },
      { 'orderby_doc.email': regex },
      { 'orderby_doc.firstname': regex },
      { 'orderby_doc.lastname': regex },
    ]

    // si es ObjectId válido, agregar comparativa directa
    if (mongoose.Types.ObjectId.isValid(qs)) {
      or.push({ _id: new mongoose.Types.ObjectId(qs) })
    }

    pipeline.push({ $match: { $or: or } })
  }

  // -----------------------------
  // 4) Project limpio
  // -----------------------------
  pipeline.push({
    $project: {
      products: 1,
      paymentIntent: 1,
      orderStatus: 1,
      createdAt: 1,
      updatedAt: 1,
      orderby: {
        _id: '$orderby_doc._id',
        email: '$orderby_doc.email',
        firstname: '$orderby_doc.firstname',
        lastname: '$orderby_doc.lastname',
      },
    },
  })

  // -----------------------------
  // 5) Sort dinámico
  // -----------------------------
  const sortMap = {
    createdAt: 'createdAt',
    amount: 'paymentIntent.amount',
    orderStatus: 'orderStatus',
  }

  const field = sortMap[sortBy] || 'createdAt'

  pipeline.push({
    $sort: {
      [field]: sortDir === 'asc' ? 1 : -1,
      _id: 1,
    },
  })

  // -----------------------------
  // 6) Facet paginado
  // -----------------------------
  pipeline.push({
    $facet: {
      data: [{ $skip: skip }, { $limit: limit }],
      meta: [{ $count: 'total' }],
    },
  })

  const result = await Order.aggregate(pipeline).allowDiskUse(true)
  const docs = result[0]?.data || []
  const total = result[0]?.meta?.[0]?.total || 0

  return res.status(200).json({
    success: true,
    data: docs,
    pagination: {
      total,
      page,
      pages: Math.max(Math.ceil(total / limit), 1),
    },
  })
})


/**
 * PUT /api/order/:id/status
 * Cambia estado; si pasa a cancelled/refunded, revierte inventario.
 */
export const updateOrderStatus = expressAsyncHandler(async (req, res) => {
  const role = req.user?.role
  if (!['admin', 'manager'].includes(role)) {
    return res.status(403).json({ success: false, message: 'Permisos insuficientes' })
  }

  const { id } = req.params
  const next = String(req.body?.status || '').toLowerCase()
  if (!isValidId(id)) return res.status(400).json({ success: false, message: 'ID inválido' })

  const allowed = ['not processed', 'cash on delivery', 'processing', 'dispatched', 'cancelled', 'delivered', 'refunded']
  if (!allowed.includes(next)) {
    return res.status(400).json({ success: false, message: 'Estado inválido' })
  }

  // Intentar con transacción, si no, fallback
  let session = null
  try {
    session = await mongoose.startSession()
    await session.withTransaction(async () => {
      const order = await Order.findById(id).session(session)
      if (!order) throw new Error('Orden no encontrada')

      const prev = order.orderStatus
      order.orderStatus = next

      if (['cancelled', 'refunded'].includes(next) && !['cancelled', 'refunded'].includes(prev)) {
        for (const p of order.products) {
          const upd = await Product.updateOne(
            { _id: p.product, isDeleted: false },
            { $inc: { quantity: +p.count, sold: -p.count } },
            { session },
          )
          if (upd.modifiedCount !== 1) {
            throw new Error('No se pudo revertir inventario')
          }
        }
      }

      await order.save({ session })
      logger.info(`🔄 Orden ${id}: ${prev} → ${next}`)
      res.status(200).json({ success: true, data: order })
    })
    session.endSession()
    return
  } catch (txErr) {
    if (session) session.endSession()
    const isNoTxSupport = /replica set|mongos|Transaction numbers/i.test(String(txErr?.message))
    if (!isNoTxSupport) {
      logger.error(`Error actualizar estado (tx): ${txErr.message}`)
      return res.status(400).json({ success: false, message: txErr.message })
    }
  }

  // Fallback sin transacción
  try {
    const order = await Order.findById(id)
    if (!order) return res.status(404).json({ success: false, message: 'Orden no encontrada' })
    const prev = order.orderStatus
    order.orderStatus = next

    if (['cancelled', 'refunded'].includes(next) && !['cancelled', 'refunded'].includes(prev)) {
      for (const p of order.products) {
        await Product.updateOne(
          { _id: p.product, isDeleted: false },
          { $inc: { quantity: +p.count, sold: -p.count } },
        )
      }
    }

    await order.save()
    logger.info(`🔄 Orden ${id}: ${prev} → ${next} (sin tx)`)
    return res.status(200).json({ success: true, data: order })
  } catch (e) {
    logger.error(`Error actualizar estado (sin tx): ${e.message}`)
    return res.status(400).json({ success: false, message: e.message })
  }
})
