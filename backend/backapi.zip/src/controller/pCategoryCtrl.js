import ProductCategory from '../models/pCategoryModel.js'
import asyncHandler from 'express-async-handler'

// Crear una nueva categoría de producto
export const createProductCategory = asyncHandler(async (req, res) => {
  const { title, description } = req.body
  if (!title) {
    return res.status(400).json({
      success: false,
      message: 'El título de la categoría es obligatorio',
    })
  }

  const existingCategory = await ProductCategory.findOne({ title })
  if (existingCategory) {
    return res
      .status(409)
      .json({ success: false, message: 'La categoría ya existe' })
  }

  const newCategory = await ProductCategory.create({ title, description })
  res.status(201).json({ success: true, data: newCategory })
})

// Obtener todas las categorías activas
export const getAllProductCategories = asyncHandler(async (req, res) => {
  const categories = await ProductCategory.find({ isActive: true })
  res.status(200).json({ success: true, data: categories })
})

// Obtener una categoría de producto por ID
export const getProductCategoryById = asyncHandler(async (req, res) => {
  const { categoryId } = req.params

  const category = await ProductCategory.findById(categoryId)
  if (!category || !category.isActive) {
    return res
      .status(404)
      .json({ success: false, message: 'Categoría no encontrada' })
  }

  res.status(200).json({ success: true, data: category })
})

// Actualizar una categoría de producto
export const updateProductCategory = asyncHandler(async (req, res) => {
  const { categoryId } = req.params
  const { title, description } = req.body

  const updatedCategory = await ProductCategory.findByIdAndUpdate(
    categoryId,
    { title, description },
    { new: true, runValidators: true },
  )

  if (!updatedCategory) {
    return res
      .status(404)
      .json({ success: false, message: 'Categoría no encontrada' })
  }

  res.status(200).json({ success: true, data: updatedCategory })
})

// Eliminar lógicamente una categoría de producto (soft delete)
export const deleteProductCategory = asyncHandler(async (req, res) => {
  const { categoryId } = req.params

  const deletedCategory = await ProductCategory.findByIdAndUpdate(
    categoryId,
    { isActive: false },
    { new: true },
  )

  if (!deletedCategory) {
    return res
      .status(404)
      .json({ success: false, message: 'Categoría no encontrada' })
  }

  res
    .status(200)
    .json({ success: true, message: 'Categoría desactivada correctamente' })
})