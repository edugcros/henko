// 📁 config/generateRefreshToken.js
import jwt from 'jsonwebtoken'
import crypto from 'crypto'
import bcrypt from 'bcrypt'
import dotenv from 'dotenv'

dotenv.config()

/**
 * Genera un refresh token seguro, con ID único (jti) y hash para almacenamiento en DB
 * @param {string} userId - ID del usuario
 * @param {number} expiresIn - Tiempo de expiración en ms (opcional, default 7 días)
 * @returns {Promise<{refreshToken:string, hashedToken:string, jti:string}>}
 */
export const generateRefreshToken = async userId => {
  // Generamos un identificador único
  const jti = crypto.randomUUID()

  // Creamos el token JWT con jti
  const refreshToken = jwt.sign(
    { sub: userId, jti },
    process.env.REFRESH_TOKEN_SECRET,
    {
      expiresIn: process.env.JWT_REFRESH_EXPIRES || '3d',
      algorithm: 'HS256',
    },
  )


  // Hash seguro para guardar en DB
  const hashedToken = await bcrypt.hash(refreshToken, 10)

  return { refreshToken, hashedToken, jti }
}

/**
 * Verifica un refresh token y retorna el payload decodificado si es válido
 * @param {string} token
 * @returns {Promise<Object>}
 */
export const verifyRefreshToken = async token => {
  try {
    const decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET, {
      algorithms: ['HS256'],
    })
    return decoded
  } catch (err) {
    throw new Error('Refresh token inválido o expirado', err)
  }

}
