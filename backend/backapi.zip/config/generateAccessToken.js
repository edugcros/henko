// 📁 config/generateAccessToken.js
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'

dotenv.config({
  path: process.env.NODE_ENV === 'production'
    ? '.env.production'
    : '.env.development',
})

if (!process.env.JWT_SECRET) {
  throw new Error('❌ JWT_SECRET no definido en el archivo .env')
}

/**
 * Genera un access token seguro para multi-tenant
 * @param {string} userId
 * @param {{
 *   role: string,
 *   tenantId: string,
 *   [key: string]: any
 * }} extraPayload
 * @returns {string}
 */
export const generateAccessToken = (userId, extraPayload = {}) => {
  if (!userId) throw new Error('❌ userId es requerido para generar access token')
  if (!extraPayload.tenantId) {
    throw new Error('❌ tenantId es requerido en el payload para arquitectura multi-tenant')
  }
  if (!extraPayload.role) {
    throw new Error('❌ role es requerido en el payload para control de permisos')
  }

  const payload = {
    sub: userId,
    tenantId: extraPayload.tenantId,
    role: extraPayload.role,
    iss: 'ecommerce-platform',
    aud: 'ecommerce-client',
    ver: 1,            // versión de token para invalidación futura
    ...extraPayload,   // si querés agregar claims adicionales
  }

  return jwt.sign(
    payload,
    process.env.JWT_SECRET,
    {
      expiresIn: process.env.JWT_ACCESS_EXPIRES || '1d',
      algorithm: 'HS256',
    },
  )

}
