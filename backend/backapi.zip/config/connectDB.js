// 📁 config/connectDB.js
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import logger from './logger.js'
import process from 'process'

dotenv.config()

mongoose.set('strictQuery', true)

const connectDB = async () => {
  if (!process.env.MONGODB_URL) {
    logger.error('❌ MONGODB_URL no está definido en el archivo .env')
    process.exit(1)
  }

  const connect = async (retries = 5) => {
    try {
      await mongoose.connect(process.env.MONGODB_URL)
      logger.info(`✅ Conectado a MongoDB - Host: ${mongoose.connection.host} - DB: ${mongoose.connection.name}`)
    } catch (error) {
      logger.error(`❌ Error de conexión a MongoDB: ${error.message}`)
      if (retries > 0) {
        logger.warn(`Reintentando conexión... (${5 - retries + 1})`)
        setTimeout(() => connect(retries - 1), 5000)
      } else {
        logger.error('❌ No se pudo conectar a MongoDB después de varios intentos.')
        process.exit(1)
      }
    }
  }

  // Eventos de conexión
  mongoose.connection.on('connected', () => {
    logger.info('🔌 MongoDB conectado')
  })

  mongoose.connection.on('error', err => {
    logger.error(`⚠️ Error en MongoDB: ${err.message}`)
  })

  mongoose.connection.on('disconnected', () => {
    logger.warn('⚠️ MongoDB desconectado')
  })

  mongoose.connection.on('reconnected', () => {
    logger.info('🔄 Reconexión a MongoDB exitosa')
  })

  await connect()
}

export default connectDB
