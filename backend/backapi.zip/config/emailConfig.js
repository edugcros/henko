// 📁 config/emailConfig.js
import nodemailer from 'nodemailer'
import dotenv from 'dotenv'
import logger from './logger.js'

dotenv.config()

// Validar variables necesarias
const requiredVars = ['EMAIL_HOST', 'EMAIL_PORT', 'EMAIL_USER', 'EMAIL_PASS']
requiredVars.forEach(key => {
  if (!process.env[key]) {
    logger.error(`❌ Falta la variable de entorno: ${key}`)
    process.exit(1)
  }
})

const isSecure = Number(process.env.EMAIL_PORT) === 465

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT),
  secure: isSecure,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  pool: true,
  maxConnections: 5,
  tls: {
    rejectUnauthorized: process.env.NODE_ENV === 'production', // Rechaza certificados no válidos en producción
  },
  connectionTimeout: 10000,
})

// Verificar conexión solo en desarrollo
if (process.env.NODE_ENV !== 'production') {
  transporter.verify ,error => {
    if (error) {
      logger.error('❌ Error al conectar con el servidor de correo', { error: error.message })
    } else {
      logger.info('✅ Servidor de correo listo para enviar mensajes')
    }
  }
}

export default transporter
