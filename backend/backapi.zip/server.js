// 📁 server.js
import connectDB from './config/connectDB.js'
import app from './app.js'
import logger from './config/logger.js'

// ---------------------------------------------------------------------------
// Validación de variables críticas
// ---------------------------------------------------------------------------
const REQUIRED_ENV = ['MONGODB_URL']

for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    logger.error(`❌ Error: Falta variable de entorno requerida: ${key}`)
    process.exit(1)
  }
}

// ---------------------------------------------------------------------------
// Configuración de puerto y servidor
// ---------------------------------------------------------------------------
const PORT = process.env.PORT || 5000
let serverInstance = null

// ---------------------------------------------------------------------------
// Arranque del servidor
// ---------------------------------------------------------------------------
const startServer = async () => {
  try {
    await connectDB()
    logger.info('🟢 Conexión a MongoDB establecida')

    serverInstance = app.listen(PORT, () => {
      logger.info(
        `🚀 Backend operativo en puerto ${PORT} | Entorno: ${process.env.NODE_ENV || 'development'}`,
      )
    })

    // Captura de errores críticos del servidor HTTP
    serverInstance.on('error', err => {
      logger.error(`❌ Error en el servidor HTTP: ${err.message}`)
      process.exit(1)
    })
  } catch (error) {
    logger.error(`❌ Error crítico al iniciar el servidor: ${error.message}`)
    process.exit(1)
  }
}

// ---------------------------------------------------------------------------
// Apagado limpio (graceful shutdown)
// ---------------------------------------------------------------------------
const shutdown = signal => {
  logger.info(`⚠️ Señal recibida: ${signal}. Iniciando apagado limpio...`)

  if (serverInstance) {
    serverInstance.close(() => {
      logger.info('🛑 Servidor cerrado correctamente')
      process.exit(0)
    })
  } else {
    process.exit(0)
  }
}

// Señales del sistema
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))

// ---------------------------------------------------------------------------
// Manejo de errores globales — evita caídas silenciosas
// ---------------------------------------------------------------------------

// Promesas no manejadas (errores en async/await sin catch)
process.on('unhandledRejection', reason => {
  logger.error('❌ Unhandled Rejection:', reason)
  shutdown('unhandledRejection')
})

// Excepciones no capturadas
process.on('uncaughtException', err => {
  logger.error('💥 Uncaught Exception:', err)
  shutdown('uncaughtException')
})

// ---------------------------------------------------------------------------
// Iniciar servidor
// ---------------------------------------------------------------------------
startServer()
